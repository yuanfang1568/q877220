package com.tools.payhelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.tools.payhelper.utils.DBManager;
import com.tools.payhelper.utils.OrderBean;
import com.tools.payhelper.utils.PayHelperUtils;

import java.util.List;

public class AlarmReceiver extends BroadcastReceiver {
    public static String MSGRECEIVED_ACTION = "com.tools.payhelper.msgreceived";

    @Override
    public void onReceive(Context context, Intent intent) {
        DBManager dbManager = new DBManager(context);
        List<OrderBean> orderBeans = dbManager.FindAllErrorOrders("0");
        Log.i("00000Heart定时任务数量", "" + orderBeans.size());
        if (orderBeans.size() == 0) {
            sendmsg(context, "当前未回调的订单数量为：" + orderBeans.size() + "  暂无定时发送任务");
        } else {
            sendmsg(context, "当前未回调的订单数量为：" + orderBeans.size() + "  正在开启定时发送任务");
        }

        for (OrderBean orderBean : orderBeans) {
            PayHelperUtils.notify(context, orderBean.getType(), orderBean.getNo(), orderBean.getMoney(), orderBean.getMark(), orderBean.getDt());
        }

        long currentTimeMillis=System.currentTimeMillis()/1000;
        long currentTimeMillis2=Long.parseLong(PayHelperUtils.getcurrentTimeMillis(context));
        long currentTimeMillis3=currentTimeMillis-currentTimeMillis2;
        if(currentTimeMillis3>60 && currentTimeMillis2!=0){
            //PayHelperUtils.sendmsg(context, "轮询任务重启中...");
            PayHelperUtils.startAlipayMonitor(context);
            //PayHelperUtils.sendmsg(context, "轮询任务重启成功");
        }
    }

    public static void sendmsg(Context context, String msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("msg", msg);

        broadCastIntent.setAction(MSGRECEIVED_ACTION);
        context.sendBroadcast(broadCastIntent);
    }
}
