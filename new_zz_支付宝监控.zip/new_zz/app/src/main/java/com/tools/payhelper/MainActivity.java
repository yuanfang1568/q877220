package com.tools.payhelper;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.tools.payhelper.utils.AbSharedUtil;
import com.tools.payhelper.utils.DBManager;
import com.tools.payhelper.utils.JsonHelper;
import com.tools.payhelper.utils.LogToFile;
import com.tools.payhelper.utils.MD5;
import com.tools.payhelper.utils.OrderBean;
import com.tools.payhelper.utils.PayHelperUtils;
import com.tools.payhelper.utils.QrCodeBean;

import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import de.robv.android.xposed.XposedBridge;

public class MainActivity extends Activity {
    public static String START_ACTION = "com.tools.payhelper.withdraw";

    public static TextView console;
    ;
    private BillReceived billReceived;
    public static String BACK_HOME_ACTION_START = "com.tools.payhelper.backstartapp";

    public static String BALANCERECEIVED_ACTION = "com.tools.payhelper.balacnereceived";
    public static String SKRECEIVED_ACTION = "com.tools.payhelper.shoukuangreceived";

    public static String BILLRECEIVED_ACTION = "com.tools.payhelper.billreceived";
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";
    public static String MSGRECEIVED_ACTION = "com.tools.payhelper.msgreceived";
    public static String TRADENORECEIVED_ACTION = "com.tools.payhelper.tradenoreceived";
    public static String LOGINIDRECEIVED_ACTION = "com.tools.payhelper.loginidreceived";
    public static String NOTIFY_ACTION = "com.tools.payhelper.notify";
    public static int WEBSEERVER_PORT = 8080;
//    private WebServer mVideoServer;

    public static String BACK_HOME_ACTION_USERID = "com.tools.payhelper.backhomeuserid";//userid广播

    private String currentWechat = "";
    private String currentAlipay = "";
    private String currentQQ = "";
    private EditText et_wechat, et_alipay;
    private Button stop;
//    private Button stop_net;

//    private EditText zhifubao_mima_title;

    //关于查询余额及限制额度
    private TextView zhifubao_balance2;
    private Button zhifubao_balance3;
    private TextView wechat_balance2;
//    private Button wechat_balance3;

    //提现
//    private Button zhifubao_balance4;

    String mainUserid = "";//支付宝userid
    Handler handlerTempTest = new Handler();
    Runnable runnableTempTest = new Runnable() {
        @Override
        public void run() {

            //一分钟生成一个支付宝的二维码，主要用来测试助手一直在首页，防止手机休眠挂掉
            System.out.println("测试返回主页" + CustomApplcation.isStart + " ");
            //取出最后一个
            if (CustomApplcation.isStart == true) {
                long nowTimetemp = new Date().getTime();
                if ((nowTimetemp - SocketClient.nowTime) > 60000) {
                    System.out.println("测试返回主页测试跳转" + (nowTimetemp - SocketClient.nowTime) + CustomApplcation.isStart + " ");
//                    try {
//                        PayHelperUtils.startAPP(CustomApplcation.getInstance().getApplicationContext(), "com.eg.android.AlipayGphone");
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }
//                    PayHelperUtils.startAPP();
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.setAction("com.payhelper.alipay.start");
                    broadCastIntent.putExtra("type", "live");
                    sendBroadcast(broadCastIntent);
//                    Intent broadCastIntent = new Intent();
//                    broadCastIntent.setAction("com.payhelper.alipay.start");
//                    broadCastIntent.putExtra("type", "qrset");
//                    broadCastIntent.putExtra("mark", "PayTest");
//                    broadCastIntent.putExtra("money", "0.01");
//                    sendBroadcast(broadCastIntent);
                }

            }
            handlerTempTest.postDelayed(this, 60000);
        }
    };
    //socket心跳机制
    Handler handlertest = new Handler();
    Runnable runnabletest = new Runnable() {
        @Override
        public void run() {
//            showData();
            System.out.println("当前状态" + client.isClosing() + client.isClosed() + "----" + client.isOpen());
            if (client.isOpen()) {
//                String my_uid = AbSharedUtil.getString(getApplicationContext(), "uid");

                String wechat_key = "";
                String ali_key = "";
                if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
                    wechat_key = (AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
                }
                if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                    ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                }

                JSONObject object = null;
                try {
                    object = new JSONObject();//创建一个总的对象，这个对象对整个json串

//                    JSONArray jsonarray = new JSONArray();//json数组，里面包含的内容为pet的所有对象
                    JSONObject jsonObj = new JSONObject();//pet对象，json形式
                    jsonObj.put("signkey", "");//向pet对象里面添加值
                    jsonObj.put("s_key", "");
//                    jsonObj.put("user_id", "" + my_uid);
                    jsonObj.put("wechat_id", "" + wechat_key);
                    jsonObj.put("alipay_id", "" + ali_key);
                    jsonObj.put("alipay_account_user_id", mainUserid);//提交userid支付宝
                    // 把每个数据当作一对象添加到数组里
//                    jsonarray.put(jsonObj);//向json数组里面添加pet对象

                    object.put("params", jsonObj);//向总对象里面添加包含pet的数组

                    object.put("type", "login");
//                    int x = (int) (Math.random() * 1000000);
//                    object.put("code_id", "" + x);
//                    随机id


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                System.out.println("发送消息" + CustomApplcation.isStart + "   " + object.toString());
                //启动，就开始发送，
                if (CustomApplcation.isStart == true) {
                    client.send(object.toString());
                }

            } else {
                if (CustomApplcation.isStart == true) {
                    websocketInit();
                }

            }

            // 循环调用实现定时刷新界面
            handlertest.postDelayed(this, 20000);
        }

    };

    SocketClient client = null;

    public void websocketInit() {
        try {
            client = new SocketClient(this, new URI(CustomApplcation.base_socketurl));
            client.setSocketListener(new SocketListener() {
                @Override
                public void init_login(String clientid) {
                    //发送http确认请求
                    sendInit_login(clientid);
                }

                @Override
                public void getpay(String mark, String money, String paytype, String keyid, String uid) {
                    //查看是否是呼叫自己的支付。通过uid和keyid来过滤
                    System.out.println("进入支付通道00");
                    if (paytype.equals("wechat")) {
                        System.out.println("进入支付通道01");
                        String wechat_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
                            wechat_key = (AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
                        }
                        if (keyid.equals(wechat_key)) {
                            System.out.println("进入支付通道01");
                            if (CustomApplcation.wecahtMaxSet) {
                                //查询是否超额
                                if (CustomApplcation.wechatMaxSetNum <= CustomApplcation.wechatNowBalance) {
                                    //已经达到额度，关闭网端
                                    stopNet(wechat_key);
                                } else {
                                    sendPay(mark, money, paytype, keyid, "", "");
                                }
                            } else {
                                sendPay(mark, money, paytype, keyid, "", "");
                            }

                        }
                    } else if (paytype.equals("alipay")) {

                        String ali_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                            ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                        }
                        if (keyid.equals(ali_key)) {
                            System.out.println("进入支付通道2");
                            //查询是否限制了额度，
                            if (CustomApplcation.alipayMaxSet) {
                                //查询是否超额
                                if (CustomApplcation.alipayMaxSetNum <= CustomApplcation.alipayNowBalance) {
                                    //已经达到额度，关闭网端
                                    stopNet(ali_key);
                                } else {
                                    sendPay(mark, money, paytype, keyid, "", "");
                                }
                            } else {
                                sendPay(mark, money, paytype, keyid, "", "");
                            }

                        }
                    } else if (paytype.equals("alipaycheck")) {

                        String ali_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                            ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                        }
                        if (keyid.equals(ali_key)) {
                            System.out.println("进入支付通道3");
                            //查询是否限制了额度，
                            if (CustomApplcation.alipayMaxSet) {
                                //查询是否超额
                                if (CustomApplcation.alipayMaxSetNum <= CustomApplcation.alipayNowBalance) {
                                    //已经达到额度，关闭网端
                                    stopNet(ali_key);
                                } else {
                                    sendPay(mark, money, paytype, keyid, uid, "");
                                }
                            } else {
                                sendPay(mark, money, paytype, keyid, uid, "");
                            }
                        }
                    } else if (paytype.equals("dingding")) {

                        String ali_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                            ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                        }
                        if (keyid.equals(ali_key)) {
                            System.out.println("进入支付通道4");
                            //查询是否限制了额度，
                            if (CustomApplcation.alipayMaxSet) {
                                //查询是否超额
                                if (CustomApplcation.alipayMaxSetNum <= CustomApplcation.alipayNowBalance) {
                                    //已经达到额度，关闭网端
                                    stopNet(ali_key);
                                } else {
                                    sendPay(mark, money, paytype, keyid, uid, "");
                                }
                            } else {
                                sendPay(mark, money, paytype, keyid, uid, "");
                            }
                        }
                    }
                }

                @Override
                public void closed(int nowcount) {

                }

                @Override
                public void checkAlipayBalance(float balance) {
                    //读取实时的目前金额=存到数据库里，=读取到的金额，加上，收到的账单金额
                    //每次收到一笔，记录下来，存到数据库作为最终值，
                    if (balance > CustomApplcation.alipayNowBalance) {
                        //不做任何操作，，
                        System.out.println("收到记录支付宝，不做任何操作");
                    } else {
                        //发送挂断当前网端的操作
                        System.out.println("收到记录支付宝，挂断网端");

                        String ali_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                            ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                        }
                        stopNet(ali_key);
                    }
                }

                @Override
                public void chetWechatBalance(float balance) {
                    if (balance > CustomApplcation.wechatNowBalance) {
                        //不做任何操作，，
                        System.out.println("收到记录微信，不做任何操作");
                    } else {
                        //发送挂断当前网端的操作
                        System.out.println("收到记录微信，挂断网端");
                        String wechat_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
                            wechat_key = (AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
                        }
                        stopNet(wechat_key);
                    }
                }

                @Override
                public void chetWechatBalanceReset() {
                    //清零微信的余额，
                    CustomApplcation.wechatNowBalance = 0;
                    wechat_balance2.setText(CustomApplcation.wechatNowBalance + "");
                    AbSharedUtil.putString(getApplicationContext(), "wechat_balance", CustomApplcation.wechatNowBalance + "");
                }

                @Override
                public void withdrawAlipay(String pw) {
                    //刚打开app，跳转过去到指定页面查询余额，查到了再返回

                }
            });
            client.connect();

        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public void websocketClosed() {
        if (client != null) {
            client.close();
        }
    }

    public void sendInit_login(String clientid) {
        HttpUtils httpUtils = new HttpUtils(5000);
        RequestParams params = new RequestParams();

//        String my_uid = AbSharedUtil.getString(getApplicationContext(), "uid");
//        String my_keyid = AbSharedUtil.getString(getApplicationContext(), "keyid");
        String wechat_key = "";
        String ali_key = "";
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
            wechat_key = (AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
            ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
        }

//        params.addBodyParameter("user_id", my_uid);
        params.addBodyParameter("wechat_id", wechat_key);
        params.addBodyParameter("alipay_id", ali_key);
        params.addBodyParameter("client_id", clientid);
        params.addBodyParameter("key", CustomApplcation.signkey);
        params.addBodyParameter("alipay_account_user_id", mainUserid);
//        params.addBodyParameter("s_key", my_keyid);

        System.out.println("当前心跳信息发送" + (CustomApplcation.base_url + CustomApplcation.init_xintiao) + " alipay_id:  " + ali_key + " client_id: " + clientid
                + " key: " + CustomApplcation.signkey + " alipay_account_user_id:" + mainUserid);
        sendmsg("当前心跳信息发送" + (CustomApplcation.base_url + CustomApplcation.init_xintiao) + " alipay_id:  " + ali_key + " client_id: " + clientid
                + " key: " + CustomApplcation.signkey + " alipay_account_user_id:" + mainUserid);
        httpUtils.send(HttpMethod.POST, CustomApplcation.base_url + CustomApplcation.init_xintiao, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
//                sendmsg("订单信息通知异常，服务器异常" + arg1);
                //update(no, arg1);

            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                System.out.println("init心跳收到了返回值=" + arg0 + "  > " + result);
            }
        });
    }

    public void sendPay(String mark, String money, String type, String keyid, String uid, String payurl) {

        //结果上传的时候，统一调用，失败再调一次
        try {
            if (type == null || type.equals("")) {
                type = "wechat";
            }
            double m = Double.parseDouble(money);
            if (type.equals("alipay")) {
                System.out.println("支付宝日志：进行支付宝1 mark=" + mark);
                if (m > 50000) {
                    System.out.println("支付宝日志：进行支付宝金额超过50000 mark=" + mark);
                    System.out.println("msg:  " + "支付宝最大支持单笔50000元支付！");
                    return;
                } else {
                    System.out.println("支付宝日志：正常启动支付宝");
                }
            } else if (type.equals("wechat")) {
                if (m > 15000) {
                    System.out.println("msg:  " + "微信最大支持单笔15000元支付！");
                    return;
                }
            } //qq支持三万最大单笔
            else if (type.equals("alipaycheck")) {
                if (m > 15000) {
                    System.out.println("msg:  " + "微信最大支持单笔15000元支付！");
                    return;
                }
            }

//
//
//            if (type.equals("qq") && !PayHelperUtils.isAppRunning(context, "com.tencent.mobileqq")) {
//                PayHelperUtils.startAPP(context, "com.tencent.mobileqq");
//            } else
            String typestr = "";
            if (type.equals("alipay") && !PayHelperUtils.isAppRunning(this, "com.eg.android.AlipayGphone")) {
                PayHelperUtils.startAPP(this, "com.eg.android.AlipayGphone");
            } else if (type.equals("alipaycheck") && !PayHelperUtils.isAppRunning(this, "com.eg.android.AlipayGphone")) {
                PayHelperUtils.startAPP(this, "com.eg.android.AlipayGphone");
            } else if (type.equals("wechat") && !PayHelperUtils.isAppRunning(this, "com.tencent.mm")) {
                PayHelperUtils.startAPP(this, "com.tencent.mm");
            } else if (type.equals("dingding") && !PayHelperUtils.isAppRunning(this, "com.alibaba.android.rimet")) {
                PayHelperUtils.startAPP(this, "com.alibaba.android.rimet");
            }
            if (type.equals("dingding")) {
                PayHelperUtils.sendAppMsg(money, mark + "---" + uid, "alipaycheck", MainActivity.this.getApplicationContext());
            }
            if (type.equals("alipaycheck")) {
                PayHelperUtils.sendAppMsg(money, mark + "---" + uid, "alipaycheck", MainActivity.this.getApplicationContext());
            } else if (type.equals("alipaychecksend")) {
                RequestParams params = new RequestParams();
                try {
                    com.alibaba.fastjson.JSONObject jsonObj = JSON.parseObject(payurl);
                    payurl = jsonObj.getString("transferNo");
                    mark = mark.split("---")[0];
                } catch (Exception e) {
                    e.printStackTrace();
                }
                params.addBodyParameter("payurl", payurl);
                params.addBodyParameter("mark", mark);
                params.addBodyParameter("money", money);
                params.addBodyParameter("type", "alipaycheck");
                params.addBodyParameter("key", CustomApplcation.signkey);
                String account = AbSharedUtil.getString(this, "account");
                if (!TextUtils.isEmpty(account)) {
                    params.addBodyParameter("account", account);
                }
                String url = CustomApplcation.base_url + CustomApplcation.init_postQrCode;
//                postPayChoose(url, params, 0);
                if (mark.equals("test")) {
                    System.out.println("支付宝日志：该笔为测试，不发送=" + mark);
                    return;
                } else {
                    System.out.println("支付宝日志：发送二维码到后端" + mark);
                    postPayChoose(url, params, 0, mark);
                    return;
                }

            }


//               /* if (!type.equals("qq")) {
//                    String t = System.currentTimeMillis() + "";
//                    t = t.substring(3);
//                    mark = mark + "|" + t;
//                }*/
//

            List<QrCodeBean> qrCodeBeans = new ArrayList<QrCodeBean>();
            DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
            PayHelperUtils.sendAppMsg(money, mark, type, this);
            int times = 0;
            while (times < 30 && qrCodeBeans.size() == 0) {
                qrCodeBeans = dbManager.FindQrCodes(mark);
                times++;
                Thread.sleep(500);
            }
            if (qrCodeBeans.size() == 0) {
                PayHelperUtils.startAPP();
                System.out.println("msg   " + "获取超时");
                System.out.println("支付宝日志：获取二维码超时 mark=" + mark);
                return;
            } else {
                String payurla = qrCodeBeans.get(0).getPayurl();
                PayHelperUtils.startAPP();
                //成功后，将二维码发出去，通过http post到接口里

                System.out.println("发送支付结果二维码开始" + payurla);
                RequestParams params = new RequestParams();
                params.addBodyParameter("payurl", payurla);
                params.addBodyParameter("mark", mark);
                params.addBodyParameter("money", money);
                params.addBodyParameter("type", type);
                params.addBodyParameter("key", CustomApplcation.signkey);
                String account = AbSharedUtil.getString(this, "account");
                if (!TextUtils.isEmpty(account)) {
                    params.addBodyParameter("account", account);
                }
                String url = CustomApplcation.base_url + CustomApplcation.init_postQrCode;
                if (mark.equals("test")) {
                    System.out.println("支付宝日志：该笔为测试，不发送=" + mark);
                    return;
                } else {
                    System.out.println("支付宝日志：发送二维码到后端" + mark);
                    postPayChoose(url, params, 0, mark);
                    return;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //二维码上传失败再传,默认nowCount=0,失败会再请求一次
    public void postPayChoose(final String url, final RequestParams params, final int nowCount, final String mark) {
        HttpUtils httpUtils = new HttpUtils(5000);
        LogToFile.e("支付流程", "发送二维码到后端开始 " + "  mark=" + mark);
        httpUtils.send(HttpMethod.POST, url, params, new RequestCallBack<String>() {
            @Override
            public void onFailure(HttpException arg0, String arg1) {
//                sendmsg("订单信息通知异常，服务器异常" + arg1);
                //重连一次
                if (nowCount == 0) {
                    postPayChoose(url, params, 1, mark);
                }
                LogToFile.e("支付流程", "发送二维码到后端错误 " + "  mark=" + mark);
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = "" + arg0.result;
                LogToFile.e("支付流程", "发送二维码到后端成功 " + "  mark=" + mark);
                System.out.println("postagain收到了返回值" + result);
//                解析返回值是否是json，不是json当作失败
                //解析指令，然后请求http
                try {
                    if (JsonHelper.isJson(result)) {
                        //解析type
                        com.alibaba.fastjson.JSONObject jsonObj = JSON.parseObject(result);
                        String type = jsonObj.getString("code");
                        if (type != null) {
                            if (type.equals("200")) {

                                System.out.println("postagain收到了返回值1");
                            } else {
                                System.out.println("postagain收到了返回值2");
                                if (nowCount == 0) {
                                    postPayChoose(url, params, 1, mark);
                                }
                            }
                        } else {
                            System.out.println("postagain收到了返回值3");
                            if (nowCount == 0) {
                                postPayChoose(url, params, 1, mark);
                            }
                        }
                    } else {
                        System.out.println("postagain收到了返回值4");
                        if (nowCount == 0) {
                            postPayChoose(url, params, 1, mark);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        setContentView(R.layout.activity_main);

        System.out.println("开始。。。。。。。。。。");
        String uid = AbSharedUtil.getString(this, "uid");
        Log.i("当前UId：", uid + "");
        //setTimer();

        console = (TextView) findViewById(R.id.console);
        console.setMovementMethod(ScrollingMovementMethod.getInstance());
        console.setGravity(Gravity.BOTTOM);
        console.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        });


        et_wechat = (EditText) findViewById(R.id.et_wechat_key);
        et_alipay = (EditText) findViewById(R.id.et_alipay_key);


        websocketInit();
        handlertest.postDelayed(runnabletest, 20000);
        handlerTempTest.postDelayed(runnableTempTest, 60000);


        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
            et_wechat.setText(AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
            et_alipay.setText(AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
        }


//        this.findViewById(R.id.start_qq).setOnClickListener(
//                new View.OnClickListener() {
//
//                    @Override
//                    public void onClick(View arg0) {
//                        Intent broadCastIntent = new Intent();
//                        broadCastIntent.setAction("com.payhelper.qq.start");
//                        String time = System.currentTimeMillis() / 10000L + "";
//                        broadCastIntent.putExtra("mark", "PayTest");
//                        broadCastIntent.putExtra("money", "0.01");
//                        sendBroadcast(broadCastIntent);
//                    }
//                });
        this.findViewById(R.id.start_alipay).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction("com.payhelper.alipay.start");
                        broadCastIntent.putExtra("type", "qrset");
                        broadCastIntent.putExtra("mark", "PayTest");
                        broadCastIntent.putExtra("money", "0.01");
                        sendBroadcast(broadCastIntent);
                    }
                });
        this.findViewById(R.id.start_wechat).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction("com.payhelper.wechat.start");
                        broadCastIntent.putExtra("mark", "PayTest");
                        broadCastIntent.putExtra("money", "0.01");
                        sendBroadcast(broadCastIntent);
                    }
                });
//        this.findViewById(R.id.setting).setOnClickListener(
//                new View.OnClickListener() {
//
//                    @Override
//                    public void onClick(View arg0) {
//                        //Intent intent = new Intent(MainActivity.this, SettingActivity.class);
//                        //startActivity(intent);
//                    }
//                });
        this.findViewById(R.id.start_app).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String wechat = et_wechat.getText().toString().trim();
                String alipay = et_alipay.getText().toString().trim();

                if (!TextUtils.isEmpty(wechat)) {
                    AbSharedUtil.putString(getApplicationContext(), "wechat_key", wechat);
                }

                if (!TextUtils.isEmpty(alipay)) {
                    AbSharedUtil.putString(getApplicationContext(), "alipay_key", alipay);
                }
                if (!TextUtils.isEmpty(wechat) || !TextUtils.isEmpty(alipay)) {
                    Toast.makeText(MainActivity.this, "保存配置成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "请填写对应Key", Toast.LENGTH_SHORT).show();
                }
            }
        });

        this.findViewById(R.id.rl_logger_detail).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, LoggerDetailActivity.class);
                intent.putExtra("logger", console.getText().toString());
                startActivity(intent);
            }
        });

        zhifubao_balance2 = (TextView) this.findViewById(R.id.zhifubao_balance2);
        zhifubao_balance3 = (Button) this.findViewById(R.id.zhifubao_balance3);
        zhifubao_balance3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getAlipayBalance();
            }
        });

        wechat_balance2 = (TextView) this.findViewById(R.id.weixin_balance2);
//        wechat_balance3=(Button) this.findViewById(R.id.weixin_balance3);
//        wechat_balance3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
//        AbSharedUtil.putString(getApplicationContext(), "wechat_balance", uid);
        String tempBalanceString = AbSharedUtil.getString(getApplicationContext(), "wechat_balance");
        float tempBalance = 0;
        if (tempBalanceString != null && !tempBalanceString.equals("")) {
            tempBalance = SocketClient.getDoubleValue(tempBalanceString);
        }
        //查询本地累加的金额，赋值
        //给static常量赋值，
        CustomApplcation.wechatNowBalance = tempBalance;
        wechat_balance2.setText(tempBalance + "");//在其他地方像数据库赋值

        stop = (Button) this.findViewById(R.id.stop_app);
//        stop_net = (Button) this.findViewById(R.id.stop_net);
//        stop_net.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                stopNet();
//            }
//        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String wechat = et_wechat.getText().toString();
                String alipay = et_alipay.getText().toString();
                String wechat_key = AbSharedUtil.getString2(MainActivity.this, "wechat_key");
                String alipay_key = AbSharedUtil.getString2(MainActivity.this, "alipay_key");
                if (!TextUtils.isEmpty(wechat) || !TextUtils.isEmpty(alipay)) {
                    if (TextUtils.isEmpty(wechat_key) && TextUtils.isEmpty(alipay_key)) {
                        Toast.makeText(MainActivity.this, "请点击保存配置后再点击开启", Toast.LENGTH_SHORT).show();
                    } else {
                        if (CustomApplcation.isStart) {
                            CustomApplcation.isStart = false;
                            stop.setText("开启");
                            Toast.makeText(MainActivity.this, "关闭成功", Toast.LENGTH_SHORT).show();
                            websocketClosed();
                        } else {
                            if (!TextUtils.isEmpty(alipay)) {

                                if (GetApksTask.getVersionAlipay(MainActivity.this).equals("10.1.38.2139")) {
                                    if (PayHelperUtils.isAppRunning(MainActivity.this, "com.eg.android.AlipayGphone")) {
                                        Intent broadCastIntent = new Intent();
                                        broadCastIntent.setAction("com.payhelper.alipay.start");
                                        broadCastIntent.putExtra("type", "solidcode");
                                        sendBroadcast(broadCastIntent);
                                    } else {
                                        Toast.makeText(MainActivity.this, "支付宝未打开", Toast.LENGTH_SHORT).show();
                                        PayHelperUtils.sendmsg(MainActivity.this, "支付宝未打开");
                                    }
                                } else {
                                    Toast.makeText(MainActivity.this, "支付宝版本不是10.1.38", Toast.LENGTH_SHORT).show();
                                    PayHelperUtils.sendmsg(MainActivity.this, "支付宝版本不是10.1.38");
                                }


                            } else {
                                websocketInit();
                                CustomApplcation.isStart = true;
                                stop.setText("关闭");
                                Toast.makeText(MainActivity.this, "启动成功", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }

                } else {
                    Toast.makeText(MainActivity.this, "请配置对应Key", Toast.LENGTH_SHORT).show();
                }
            }
        });
//        zhifubao_balance4 = (Button) this.findViewById(R.id.withdraw);
//        zhifubao_balance4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                getAlipayWithDraw("");
//            }
//        });

        //开启accessibility
        //   Intent intent = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
        //    startActivity(intent);
        //注册广播
        billReceived = new BillReceived();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BILLRECEIVED_ACTION);
        intentFilter.addAction(MSGRECEIVED_ACTION);
        intentFilter.addAction(QRCODERECEIVED_ACTION);
        intentFilter.addAction(SKRECEIVED_ACTION);
        intentFilter.addAction(LOGINIDRECEIVED_ACTION);
        intentFilter.addAction(TRADENORECEIVED_ACTION);
        intentFilter.addAction(BALANCERECEIVED_ACTION);
        intentFilter.addAction(START_ACTION);
        intentFilter.addAction(BACK_HOME_ACTION_USERID);
        intentFilter.addAction(BACK_HOME_ACTION_START);

        intentFilter.addAction(SAVEALIPAYCOOKIE_ACTION);
        intentFilter.addAction(GETTRADEINFO_ACTION);
        registerReceiver(billReceived, intentFilter);

        AbSharedUtil.putString(this, "nowminute", "0");
        PayHelperUtils.startAlipayMonitor(this);
        //alarmReceiver=new AlarmReceiver();
        // IntentFilter alarmIntentFilter = new IntentFilter();
        //   alarmIntentFilter.addAction(NOTIFY_ACTION);
        //   registerReceiver(alarmReceiver, alarmIntentFilter);
        sendmsg("当前软件版本:" + PayHelperUtils.getVerName(getApplicationContext()));
        startService(new Intent(this, DaemonService.class));
    }

    private AlarmReceiver alarmReceiver;
    public static String SAVEALIPAYCOOKIE_ACTION = "com.tools.payhelper.savealipaycookie";
    public static String GETTRADEINFO_ACTION = "com.tools.payhelper.gettradeinfo";
    public static Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            String txt = msg.getData().getString("log");
            if (console != null) {
                if (console.getText() != null) {
                    if (console.getText().toString().length() > 10000) {
                        console.setText("日志定时清理完成..." + "\n\n" + txt);
                    } else {
                        console.setText(console.getText().toString() + "\n\n" + txt);
                    }

                } else {
                    console.setText(txt);
                }
            }
            console.post(new Runnable() {
                @Override
                public void run() {

                    int scrollAmount = console.getLayout().getLineTop(console.getLineCount())
                            - console.getHeight();
                    if (scrollAmount > 0)
                        console.scrollTo(0, scrollAmount);
                    else
                        console.scrollTo(0, 0);
                }
            });
            super.handleMessage(msg);
        }

    };

    @Override
    protected void onDestroy() {
        unregisterReceiver(billReceived);
//        mVideoServer.stop();
        //stopTimer();
        super.onDestroy();
    }

    @Override
    protected void onResume() {

        super.onResume();


    }


    public static void sendmsg(String txt) {
        Message msg = new Message();
        msg.what = 1;
        Bundle data = new Bundle();
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String d = dateFormat.format(date);
        data.putString("log", d + ":" + txt);
        msg.setData(data);
        try {
            handler.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // 过滤按键动作
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keyCode, event);
    }

    //自定义接受订单通知广播
    class BillReceived extends BroadcastReceiver {
        @Override
        public void onReceive(final Context context, Intent intent) {
            try {

                if (intent.getAction().contentEquals(SKRECEIVED_ACTION)) {

                    String money = intent.getStringExtra("money");
                    String mark = intent.getStringExtra("mark");
                    String type = intent.getStringExtra("type");
                    String payurl = intent.getStringExtra("payurl");
                    Log.e("shoudao", "" + payurl);

                    DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    String dt = System.currentTimeMillis() + "";
                    DecimalFormat df = new DecimalFormat("0.00");
                    money = df.format(Double.parseDouble(money));
                    dbManager.addQrCode(new QrCodeBean(money, mark, type, payurl, dt));
                    sendmsg("生成成功,金额:" + money + "备注:" + mark + "二维码:" + payurl);
                    //     sendPay(mark, money, paytype, keyid,"","");
                    sendPay(mark, money, "alipaychecksend", "", "", payurl);
                } else if (intent.getAction().contentEquals(BILLRECEIVED_ACTION)) {
                    String no = intent.getStringExtra("bill_no");
                    String money = intent.getStringExtra("bill_money");
                    String mark = intent.getStringExtra("bill_mark");
                    String type = intent.getStringExtra("bill_type");
                    String payUserId = intent.getStringExtra("bill_pay_user_id");


                    DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    String dt = System.currentTimeMillis() + "";
                    dbManager.addOrder(new OrderBean(money, mark, type, no, dt, "", 0));
                    if (type.equals("alipay")) {
                        type = "支付宝";
                        CustomApplcation.alipayNowBalance = CustomApplcation.alipayNowBalance + Float.parseFloat(money);
                        zhifubao_balance2.setText(CustomApplcation.alipayNowBalance + "");
                        if (CustomApplcation.alipayMaxSet) {
                            if (CustomApplcation.alipayMaxSetNum > CustomApplcation.alipayNowBalance) {
                                //不做任何操作，，
                                System.out.println("收到记录支付宝，不做任何操作");
                            } else {
                                //发送挂断当前网端的操作
                                System.out.println("收到记录支付宝，挂断网端");

                                String ali_key = "";
                                if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                                    ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                                }
                                stopNet(ali_key);
                            }
                        }
                    } else if (type.equals("wechat")) {
                        type = "微信";
                        CustomApplcation.wechatNowBalance = CustomApplcation.wechatNowBalance + Float.parseFloat(money);
                        wechat_balance2.setText(CustomApplcation.wechatNowBalance + "");
                        AbSharedUtil.putString(getApplicationContext(), "wechat_balance", CustomApplcation.wechatNowBalance + "");
                        if (CustomApplcation.wecahtMaxSet) {


                            if (CustomApplcation.wechatMaxSetNum > CustomApplcation.wechatNowBalance) {
                                //不做任何操作，，
                                System.out.println("收到记录支付宝，不做任何操作");
                            } else {
                                //发送挂断当前网端的操作
                                String wechat_key = "";
                                if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
                                    wechat_key = (AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
                                }
                                stopNet(wechat_key);
                            }
                        }

                    } else if (type.equals("qq")) {
                        type = "QQ";
                    }
                    if (no.equals("error")) {
                        sendmsg("收到" + type + "，金额：" + money + "\n" + "备注：" + mark);
                    } else {
                        sendmsg("收到" + type + "订单号：" + no + "，金额：" + money + "\n" + "备注：" + mark);
                    }
                    notify(type, no, money, mark, dt, payUserId);
                } else if (intent.getAction().contentEquals(TRADENORECEIVED_ACTION)) {
                    Log.i("00000Heart", "商家服务来了");
                    //支付宝商家订单
                    final String tradeno = intent.getStringExtra("tradeno");
                    String cookie = intent.getStringExtra("cookie");
                    final DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    if (!dbManager.isExistTradeNo(tradeno)) {
                        dbManager.addTradeNo(tradeno);
                        Log.i("00000Heart", "当前订单存不存在？不存在，发送" + tradeno);
                        String url = "https://tradeeportlet.alipay.com/wireless/tradeDetail.htm?tradeNo=" + tradeno + "&source=channel&_from_url=https%3A%2F%2Frender.alipay.com%2Fp%2Fz%2Fmerchant-mgnt%2Fsimple-order._h_t_m_l_%3Fsource%3Dmdb_card";
                        try {
                            HttpUtils httpUtils = new HttpUtils(15000);
                            httpUtils.configResponseTextCharset("GBK");
                            RequestParams params = new RequestParams();
                            params.addHeader("Cookie", cookie);

                            httpUtils.send(HttpMethod.GET, url, params, new RequestCallBack<String>() {

                                @Override
                                public void onFailure(HttpException arg0, String arg1) {
                                    Log.i("00000Heart", "商家服务失败");
                                    PayHelperUtils.sendmsg(context, "商家服务查询服务器异常" + arg1);
                                }

                                @Override
                                public void onSuccess(ResponseInfo<String> arg0) {
                                    Log.i("00000Heart", "商家服务成功");
                                    try {
                                        String result = arg0.result;
                                        Log.i("00000Heart", "商家服务成功爬虫result" + result);
                                        Document document = Jsoup.parse(result);
                                        Elements elements = document.getElementsByClass("trade-info-value");
                                        if (elements.size() >= 5) {
                                            String money = elements.get(2).ownText();
                                            String mark = elements.get(3).ownText();

                                            //信用卡
                                            if (money.contains("-")) {
                                                money = elements.get(3).ownText();
                                                mark = elements.get(4).ownText();
                                            }

                                            String dt = System.currentTimeMillis() + "";
                                            Log.i("00000Heart", "商家服务成功爬虫result0" + elements.get(0).ownText() + "  1" +
                                                    elements.get(1).ownText() + "   2" + elements.get(2).ownText() + "   3" + elements.get(3).ownText() + "  4" + elements.get(4).ownText() + "  5" + elements.get(5).ownText());
                                            Log.i("00000Heart", "商家服务来了" + money + "   " + mark);
                                            //    dbManager.addOrder(new OrderBean(money, mark, "alipay", tradeno, dt, "", 0));
                                            DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                                            dbManager.addOrder(new OrderBean(money, mark, "alipay", tradeno, dt, "", 0));
                                            sendmsg("收到支付宝商家订单,订单号：" + tradeno + "金额：" + money + "备注：" + mark);
                                            notify2("alipay", tradeno, money, mark, dt);
                                            CustomApplcation.alipayNowBalance = CustomApplcation.alipayNowBalance + Float.parseFloat(money);
                                            zhifubao_balance2.setText(CustomApplcation.alipayNowBalance + "");
                                            if (CustomApplcation.alipayMaxSet) {
                                                if (CustomApplcation.alipayMaxSetNum > CustomApplcation.alipayNowBalance) {
                                                    //不做任何操作，，
                                                    System.out.println("收到记录支付宝，不做任何操作");
                                                } else {
                                                    //发送挂断当前网端的操作
                                                    System.out.println("收到记录支付宝，挂断网端");

                                                    String ali_key = "";
                                                    if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                                                        ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                                                    }
                                                    stopNet(ali_key);
                                                }
                                            }
                                        }
                                    } catch (Exception e) {
                                        Log.i("00000Heart", "商家服务来了异常");
                                        PayHelperUtils.sendmsg(context, "TRADENORECEIVED_ACTION-->>onSuccess异常" + e.getMessage());
                                    }
                                }
                            });
                        } catch (Exception e) {
                            Log.i("00000Heart", "商家服务来了异常2");
                            PayHelperUtils.sendmsg(context, "TRADENORECEIVED_ACTION异常" + e.getMessage());
                        }
                    } else {
                        Log.i("00000Heart", "当前订单存不存在？存在" + tradeno);
                    }
                } else if (intent.getAction().contentEquals(QRCODERECEIVED_ACTION)) {
                    String money = intent.getStringExtra("money");
                    String mark = intent.getStringExtra("mark");
                    String type = intent.getStringExtra("type");
                    String payurl = intent.getStringExtra("payurl");
                    DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
                    String dt = System.currentTimeMillis() + "";
                    dbManager.addQrCode(new QrCodeBean(money, mark, type, payurl, dt));
                    sendmsg("生成订单成功,金额:" + money + "\n" + "备注:" + mark);
                    if (!mark.contains("Test")) {
                        CustomApplcation.temp_mark = mark;
                        //AbSharedUtil.putString(getApplicationContext(), "temp_mark", mark);
                        Log.i("6666Heart", "当前mark保存" + CustomApplcation.temp_mark);
                    }
                    PayHelperUtils.startAPP();
                } else if (intent.getAction().contentEquals(MSGRECEIVED_ACTION)) {
                    String msg = intent.getStringExtra("msg");
                    sendmsg(msg);
                } else if (intent.getAction().contentEquals(LOGINIDRECEIVED_ACTION)) {
                    String loginid = intent.getStringExtra("loginid");
                    String type = intent.getStringExtra("type");
                    if (!TextUtils.isEmpty(loginid)) {
                        if (type.equals("wechat") && !loginid.equals(currentWechat)) {
                            sendmsg("当前登录微信账号：" + loginid);
                            currentWechat = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else if (type.equals("alipay") && !loginid.equals(currentAlipay)) {
                            sendmsg("当前登录支付宝账号：" + loginid);
                            currentAlipay = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        } else if (type.equals("qq") && !loginid.equals(currentQQ)) {
                            sendmsg("当前登QQ账号：" + loginid);
                            currentQQ = loginid;
                            AbSharedUtil.putString(getApplicationContext(), type, loginid);
                        }
                    }
                } else if (intent.getAction().contentEquals(BALANCERECEIVED_ACTION)) {
                    PayHelperUtils.startAPP();
                    String balance = intent.getStringExtra("balance");
                    String type = intent.getStringExtra("type");
                    if (type.equals("alipay")) {
                        CustomApplcation.alipayNowSet = true;
                        CustomApplcation.alipayNowBalance = Float.parseFloat(balance);
                        zhifubao_balance2.setText(CustomApplcation.alipayNowBalance + "");

                    } else if (type.equals("wechat")) {
                        CustomApplcation.wechatNowSet = true;
                        CustomApplcation.wechatNowBalance = Float.parseFloat(balance);
                        wechat_balance2.setText(CustomApplcation.wechatNowBalance + "");
                        AbSharedUtil.putString(getApplicationContext(), "wechat_balance", CustomApplcation.wechatNowBalance + "");
                    }
                    System.out.println("当前平台" + type + "  余额：" + balance);
                    //settext,
                } else if (intent.getAction().contentEquals(START_ACTION)) {
                    PayHelperUtils.startAPP();

                    //提现结束后，请求是否打开网关接口，打开的话，就重新启动，并且初始金额指定为0

                    //先设置初始金额
                    CustomApplcation.alipayNowSet = true;
                    CustomApplcation.alipayNowBalance = 0;
                    zhifubao_balance2.setText(CustomApplcation.alipayNowBalance + "");
                    //请求网关看是否打开
                    String ali_key = "";
                    if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
                        ali_key = (AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
                    }
                    openStarNet(ali_key, "service_auto");
                } else if (intent.getAction().contentEquals(BACK_HOME_ACTION_USERID)) {
                    //读取userid并且显示，
                    String userid = intent.getStringExtra("userid");
                    System.out.println("获取到了userid" + userid);
                    mainUserid = userid;
                    websocketInit();
                    CustomApplcation.isStart = true;
                    stop.setText("关闭");
                    Toast.makeText(MainActivity.this, "启动成功", Toast.LENGTH_SHORT).show();
                    PayHelperUtils.startAPP();
                } else if (intent.getAction().contentEquals(BACK_HOME_ACTION_START)) {
                    PayHelperUtils.startAPP();
                }
            } catch (Exception e) {
                XposedBridge.log(e.getMessage());
            }
        }

        public void notify(String type, final String no, String money, String mark, String dt, String payUserId) {

            Log.i("#####", "回调" + type + "," + no + "," + money + "," + mark + "," + dt + "," + payUserId);

            if (mark.equals("test")) {
                //测试用，不回调
                update(no, "0");
                return;
            }
//            if (!mark.contains("|")) {
//                mark = CustomApplcation.temp_mark;
//            }


            //截取|字符串
            String str1 = "";
            String str2 = "";

            if (mark.contains("|") && mark.contains(")")) {
                str1 = mark.substring(mark.indexOf(")") + 1, mark.indexOf("|"));
                str2 = mark.substring(mark.indexOf("|") + 1);
            } else if (mark.contains("|")) {
                str1 = mark.substring(0, mark.indexOf("|"));
                str2 = mark.substring(mark.indexOf("|") + 1);

            } else if (mark.contains("ORDER") && mark.contains("QX")) {
//                ORDER10054QX1000734
                str1 = mark.substring(5, mark.indexOf("Q"));
                str2 = mark.substring(mark.indexOf("X") + 1);

            } else if (mark.contains("=姓")) {
                mark = mark.substring(0, mark.indexOf("=姓"));
            } else {
                Log.i("错误", "mark有误");
            }


            String notifyurl = AbSharedUtil.getString(getApplicationContext(), "notifyurl");
            String signkey = AbSharedUtil.getString(getApplicationContext(), "signkey");
            if (TextUtils.isEmpty(notifyurl) || TextUtils.isEmpty(signkey)) {
                sendmsg("订单信息通知异常，URL为空");
                //update(no, "异步通知地址为空");
                update(no, "0");
                return;
            }
            String wxid = AbSharedUtil.getString(getApplicationContext(), "account");
            if (type.equals("qq")) {
                wxid = AbSharedUtil.getString(getApplicationContext(), "qq");
            }
            HttpUtils httpUtils = new HttpUtils(15000);
            //String sign = MD5.md5(dt + mark + money + no + type + signkey);
            //String sign = MD5.md5(signkey + money + str1);
            RequestParams params = new RequestParams();
            //params.addBodyParameter("type", type);
            //params.addBodyParameter("mark", mark);
            // params.addBodyParameter("account_key", signkey);
            // params.addBodyParameter("amount", money);
            // params.addBodyParameter("out_trade_no", str1);

            String loginId = AbSharedUtil.getString(getApplicationContext(), "alipay");

            params.addBodyParameter("dt", dt);
            params.addBodyParameter("no", no);
            params.addBodyParameter("money", money.replace("￥", ""));
            params.addBodyParameter("id", str1);
            params.addBodyParameter("order", str2);
            params.addBodyParameter("key", signkey);
            params.addBodyParameter("today_money", "");
            params.addBodyParameter("today_pens", "");
            params.addBodyParameter("payUserId", payUserId);
            params.addBodyParameter("userId", loginId);
            String sign = MD5.md5(dt + money + no + "cfepaynet123456");

            params.addBodyParameter("sign", sign);

            System.out.println("日志：发送支付结果1 mark=" + mark + "  " + payUserId);

            if (!TextUtils.isEmpty(wxid)) {
                params.addBodyParameter("account", wxid);
            }
            //params.addBodyParameter("sign", sign);
            LogToFile.e("支付流程", "发送支付到后端  " + notifyurl + " mark=" + mark);
            final String tempMark = mark;
            httpUtils.send(HttpMethod.POST, notifyurl, params, new RequestCallBack<String>() {

                @Override
                public void onFailure(HttpException arg0, String arg1) {
                    LogToFile.e("支付流程", "发送支付到后端错误 " + arg1 + " mark=" + tempMark);
                    sendmsg("发送异步通知异常，服务器异常" + arg1);
                    //update(no, arg1);
                    update(no, "0");
                }

                @Override
                public void onSuccess(ResponseInfo<String> arg0) {
                    String result = arg0.result;
                    LogToFile.e("支付流程", "发送支付到后端返回值 " + result + " mark=" + tempMark);
                    if (result.contains("200")) {
                        sendmsg("发送订单通知成功");
                        Log.i("11111Heart", result);
                        update(no, "1");
                    } else {
                        sendmsg("发送订单通知失败");
                        Log.i("11111Heart", result);
                        update(no, "0");
                    }
                    //update(no, result);
                }
            });
        }

        public void notify2(String type, final String no, String money, String mark, String dt) {

            if (mark.equals("test")) {
                //测试用，不回调
                update(no, "0");
                return;
            }

//            if (!mark.contains("|")) {
//                mark = CustomApplcation.temp_mark;
//            }
            System.out.println("支付宝日志：发送支付结果2 mark=" + mark + "  ");

            //截取|字符串
            String str1 = "";
            String str2 = "";

            if (mark.contains("|") && mark.contains(")")) {
                str1 = mark.substring(mark.indexOf(")") + 1, mark.indexOf("|"));
                str2 = mark.substring(mark.indexOf("|") + 1);
            } else if (mark.contains("|")) {
                str1 = mark.substring(0, mark.indexOf("|"));
                str2 = mark.substring(mark.indexOf("|") + 1);

            } else if (mark.contains("ORDER") && mark.contains("QX")) {
//                ORDER10054QX1000734
                str1 = mark.substring(5, mark.indexOf("Q"));
                str2 = mark.substring(mark.indexOf("X") + 1);

            } else if (mark.contains("=姓")) {
                mark = mark.substring(0, mark.indexOf("=姓"));
            } else {
                Log.i("错误", "mark有误");
            }


            String notifyurl = AbSharedUtil.getString(getApplicationContext(), "notifyurl");
            String signkey = AbSharedUtil.getString(getApplicationContext(), "signkey");
            if (TextUtils.isEmpty(notifyurl) || TextUtils.isEmpty(signkey)) {
                sendmsg("订单信息通知异常，URL为空");
                //update(no, "异步通知地址为空");
                update(no, "0");
                return;
            }
            String wxid = AbSharedUtil.getString(getApplicationContext(), "account");
            if (type.equals("qq")) {
                wxid = AbSharedUtil.getString(getApplicationContext(), "qq");
            }
            HttpUtils httpUtils = new HttpUtils(15000);
            //String sign = MD5.md5(dt + mark + money + no + type + signkey);
            //String sign = MD5.md5(signkey + money + str1);
            RequestParams params = new RequestParams();
            //params.addBodyParameter("type", type);
            //params.addBodyParameter("mark", mark);
            // params.addBodyParameter("account_key", signkey);
            // params.addBodyParameter("amount", money);
            // params.addBodyParameter("out_trade_no", str1);

            params.addBodyParameter("dt", dt);
            params.addBodyParameter("no", no);
            params.addBodyParameter("money", money.replace("￥", ""));
            params.addBodyParameter("id", str1);
            params.addBodyParameter("order", str2);
            params.addBodyParameter("key", signkey);
            params.addBodyParameter("today_money", "");
            params.addBodyParameter("today_pens", "");


            if (!TextUtils.isEmpty(wxid)) {
                params.addBodyParameter("account", wxid);
            }
            //params.addBodyParameter("sign", sign);
            LogToFile.e("支付流程", "2发送支付到后端  " + notifyurl + " mark=" + mark);
            final String tempMark = mark;
            httpUtils.send(HttpMethod.POST, notifyurl, params, new RequestCallBack<String>() {

                @Override
                public void onFailure(HttpException arg0, String arg1) {
                    sendmsg("发送异步通知异常，服务器异常" + arg1);
                    //update(no, arg1);
                    LogToFile.e("支付流程", "2发送支付到后端错误 " + arg1 + " mark=" + tempMark);
                    update(no, "0");
                }

                @Override
                public void onSuccess(ResponseInfo<String> arg0) {
                    String result = arg0.result;
                    LogToFile.e("支付流程", "2发送支付到后端返回值 " + result + "  mark");
                    if (result.contains("200")) {
                        sendmsg("发送订单通知成功");
                        Log.i("11111Heart", result);
                        update(no, "1");
                    } else {
                        sendmsg("发送订单通知失败");
                        Log.i("11111Heart", result);
                        update(no, "0");
                    }
                    //update(no, result);
                }
            });
        }

        private void update(String no, String result) {
            DBManager dbManager = new DBManager(CustomApplcation.getInstance().getApplicationContext());
            dbManager.updateOrder(no, result);
        }
    }


    /*key_id =key_id
thoroughfare = wechat_auto（商户版微信）、alipay_auto（商户版支付宝）、service_auto（服务版微信/支付宝）*/
    public void stopNet(String keyId) {
        HttpUtils httpUtils = new HttpUtils(15000);
        RequestParams params = new RequestParams();

        params.addBodyParameter("key_id", keyId);
        params.addBodyParameter("thoroughfare", "service_auto");

        System.out.println("发送关闭网端参数  key_id:" + keyId + "  thoroughfare:" + "service_auto");

        httpUtils.send(HttpMethod.POST, CustomApplcation.base_url + CustomApplcation.stopNet, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                sendmsg("发送关闭网端失败" + arg1);
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                System.out.println("发送关闭网端返回值" + result);
                if (result.contains("200")) {
                    sendmsg("发送关闭网端成功");

                    CustomApplcation.isStart = false;
                    stop.setText("开启");
                    Toast.makeText(MainActivity.this, "关闭成功", Toast.LENGTH_SHORT).show();
                    websocketClosed();


                } else {
                    sendmsg("发送关闭网端失败");
                }
            }
        });
    }



     /*key_id =key_id
 thoroughfare = wechat_auto（商户版微信）、alipay_auto（商户版支付宝）、service_auto（服务版微信/支付宝）*/
    //重新打开网关


    public void openStarNet(String keyId, String type) {
        HttpUtils httpUtils = new HttpUtils(15000);
        RequestParams params = new RequestParams();

        params.addBodyParameter("key_id", keyId);
        params.addBodyParameter("thoroughfare", type);

        System.out.println("发送打开网端参数  notyurl=" + CustomApplcation.base_url + CustomApplcation.startNet + "  key_id:" + keyId + "  thoroughfare:" + type);

        httpUtils.send(HttpMethod.POST, CustomApplcation.base_url + CustomApplcation.startNet, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                sendmsg("发送重新打开网端失败" + arg1);
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                try {


                    String result = arg0.result;
                    System.out.println("发送打开网端返回值" + result);
                    if (result.contains("200")) {
                        //提现结束后，
                        if (JsonHelper.isJson(result)) {
                            //解析type
                            JSONObject jsonArray = new JSONObject(result);
//                            JSONObject jsonObj = JSON.parseObject(result);
//                            jsonObj.("continue");
                            boolean type = jsonArray.optBoolean("continue", false);

                            if (type) {
                                //重新打开网关，点击启动按钮，启动网关
                                sendmsg("重新打开网端");


                                if (GetApksTask.getVersionAlipay(MainActivity.this).equals("10.1.38.2139")) {
                                    if (PayHelperUtils.isAppRunning(MainActivity.this, "com.eg.android.AlipayGphone")) {
                                        Intent broadCastIntent = new Intent();
                                        broadCastIntent.setAction("com.payhelper.alipay.start");
                                        broadCastIntent.putExtra("type", "solidcode");
                                        sendBroadcast(broadCastIntent);
                                    } else {
                                        Toast.makeText(MainActivity.this, "支付宝未打开", Toast.LENGTH_SHORT).show();
                                        PayHelperUtils.sendmsg(MainActivity.this, "支付宝未打开");
                                    }
                                } else {
                                    Toast.makeText(MainActivity.this, "支付宝版本不是10.1.38", Toast.LENGTH_SHORT).show();
                                    PayHelperUtils.sendmsg(MainActivity.this, "支付宝版本不是10.1.38");
                                }
                            } else {
                                //不打开网关，啥也不做
                                sendmsg("不打开网端");
                            }
                        } else {

                        }
                    } else {
                        sendmsg("发送打开网端失败");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    //支付宝
    //刚打开app，跳转过去到指定页面查询余额，查到了再返回
    public void getAlipayBalance() {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction("com.payhelper.alipay.start");
        broadCastIntent.putExtra("type", "balance");
        sendBroadcast(broadCastIntent);
    }


}

