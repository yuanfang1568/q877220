package com.tools.payhelper;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

import com.alibaba.fastjson.JSON;
import com.google.myjson.Gson;
import com.tools.payhelper.utils.PayHelperUtils;
import com.tools.payhelper.utils.XmlToJson;
import android.os.Handler;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import java.lang.reflect.InvocationTargetException;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class WechatHook {

	public static ClassLoader classLoader;
	public static Handler handler;
	public static Context activity;
	public static String BILLRECEIVED_ACTION = "com.tools.payhelper.billreceived";
	public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";


	public static void  getPayUrl(double money,String remark) {

	}



	boolean tempBoolean=false;//是否开启检查数据
	boolean tempIsget=false;//是否获取到了数据
	public void hookActivityCreateFinish(final Context context, final ClassLoader classLoader) {

	}


	public static class Model {

	}
}
