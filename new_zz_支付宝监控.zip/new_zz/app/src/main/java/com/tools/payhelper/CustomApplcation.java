package com.tools.payhelper;


import android.content.Context;
import android.support.multidex.MultiDex;
import android.support.multidex.MultiDexApplication;

import com.tencent.bugly.crashreport.CrashReport;
import com.tools.payhelper.utils.AbSharedUtil;
import com.tools.payhelper.utils.LogToFile;
import com.tools.payhelper.utils.PercentageScreenHelper;

/**
 * 自定义全局Applcation类
 *
 * @author smile
 * @ClassName: CustomApplcation
 * @Description: TODO
 * @date 2014-5-19 下午3:25:00
 */
public class CustomApplcation extends MultiDexApplication {

    public static CustomApplcation mInstance;
    private static Context context;

    public static String url = "Pay_AliCode_notify.html";
    public static String heart_url="server/index/uploadLoginData";
    public static boolean isStart = false;
    public static String temp_mark;

    public static String base_url = "http://www.39qy54.cn/";
    public static String signkey = "cfepaynet123456";
    public static String base_socketurl="ws://103.82.54.202:39500/";

    public static String init_xintiao="Pay_AliCode_xintiao.html";
    public static String init_postQrCode="server/socketGateway/uploadServerOrderCode";
    public static String login_url = "server/index/loginDo";
    public static String stopNet="server/socketGateway/closeReceiving";

    public static String startNet="server/socketGateway/reopenReceiving";

    //关于金额上限的设置相关参数
    public static boolean alipayMaxSet=false;
    public static float alipayMaxSetNum=0;

    public static boolean alipayNowSet=false;
    public static float alipayNowBalance=0;

    public static boolean wecahtMaxSet=false;
    public static float wechatMaxSetNum=0;

    public static boolean wechatNowSet=false;
    public static float wechatNowBalance=0;
    //用本地存储，每次收到金额，存储支付宝或者微信


    static int error_count=0;
    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
        new PercentageScreenHelper(this, 375).activate();//初始化pt，屏幕适配，将pt转为像素
    }

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        mInstance = this;
        LogToFile.init(this);
        error_count=0;
        CrashReport.initCrashReport(getApplicationContext(), "f1af735020", false);

        //关于余额问题，赋各种变量初始值
        alipayMaxSet=false;
        alipayMaxSetNum=0;

         alipayNowSet=false;
         alipayNowBalance=0;

        wecahtMaxSet=false;
         wechatMaxSetNum=0;

         wechatNowSet=false;
         wechatNowBalance=0;
        //余额查询

//        if (AbSharedUtil.getString(getApplicationContext(), "notifyurl") == null) {
            AbSharedUtil.putString(getApplicationContext(), "notifyurl", base_url + url);
//        }
//        if (AbSharedUtil.getString(getApplicationContext(), "returnurl") == null) {
            AbSharedUtil.putString(getApplicationContext(), "returnurl", base_url + url);
//        }

//        if (AbSharedUtil.getString(getApplicationContext(), "signkey") == null) {
            AbSharedUtil.putString(getApplicationContext(), "signkey", signkey);
//        }


    }

    public static CustomApplcation getInstance() {
        return mInstance;
    }

    public static Context getContext() {
        return context;
    }
}
