package com.tools.payhelper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Handler;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import com.tools.payhelper.utils.PayHelperUtils;


/**
 * author : Colin
 * e-mail : Colin12138@gmail.com
 * qq     : 3327763437
 * date   : 2019/1/238:33 PM
 */
public class RedEnvelopService extends AccessibilityService {
    int mX ,mY;
    String SNS = "com.alipay.android.phone.discovery.envelope.get.SnsCouponDetailActivity";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        String className = (String) event.getClassName();
//        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED){
//            PayHelperUtils.sendmsg(getApplicationContext(),event.getClassName().toString());
//        }
        Log.e("infoss",className+"----------"+SNS);
        if (className.equals(SNS)){
            mX = 1000;
            mY = 300;
            openRedPacket();
        }
    }

    @Override
    public void onInterrupt() {

    }

    private void openRedPacket() {

        final int x = mX;
        final int y = mY;
        final int y1 = mY+10;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.e("infoss",x+"----------"+y);
                dispatchGestureView(x, y);
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                dispatchGestureView(x,y1);
            }
        }, 300);
    }


    /**
     * 模拟点击事件
     * @param x 横坐标
     * @param y 纵坐标
     */
    private void dispatchGestureView(int x, int y) {
        Point position = new Point(x, y);
        GestureDescription.Builder builder = new GestureDescription.Builder();
        Path p = new Path();
        p.moveTo(position.x, position.y);
        builder.addStroke(new GestureDescription.StrokeDescription(p, 0L, 1000L));
        GestureDescription gesture = builder.build();
        dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription gestureDescription) {
                super.onCompleted(gestureDescription);
                PayHelperUtils.sendmsg(getApplicationContext(),"红包已拆开");
            }

            @Override
            public void onCancelled(GestureDescription gestureDescription) {
                super.onCancelled(gestureDescription);
                PayHelperUtils.sendmsg(getApplicationContext(),"红包未拆开");
            }
        }, null);
    }
}
