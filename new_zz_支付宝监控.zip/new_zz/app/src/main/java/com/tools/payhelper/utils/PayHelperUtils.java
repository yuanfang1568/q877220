package com.tools.payhelper.utils;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;
import com.tools.payhelper.CustomApplcation;
import com.tools.payhelper.MainActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;
import de.robv.android.xposed.XposedHelpers;

public class PayHelperUtils {

    public static String WECHATSTART_ACTION = "com.payhelper.wechat.start";
    public static String ALIPAYSTART_ACTION = "com.payhelper.alipay.start";
    public static String QQSTART_ACTION = "com.payhelper.qq.start";
    public static String YUNSHANFUTART_ACTION = "com.payhelper.yunshanfu.start";
    public static String MSGRECEIVED_ACTION = "com.tools.payhelper.msgreceived";
    public static String LOGINIDRECEIVED_ACTION = "com.tools.payhelper.loginidreceived";
    public static String TRADENORECEIVED_ACTION = "com.tools.payhelper.tradenoreceived";
    public static List<QrCodeBean> qrCodeBeans = new ArrayList<QrCodeBean>();
    public static List<OrderBean> orderBeans = new ArrayList<OrderBean>();
    public static boolean isFirst=true;
    public static String getQQLoginId(Context context) {
        String loginId = "";
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("Last_Login", 0);
            loginId = sharedPreferences.getString("uin", "");
        } catch (Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
        return loginId;
    }

    public static void sendLoginId(String loginId, String type, Context context) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(LOGINIDRECEIVED_ACTION);
        broadCastIntent.putExtra("type", type);
        broadCastIntent.putExtra("loginid", loginId);
        context.sendBroadcast(broadCastIntent);
    }

    public static int isActivityTop(Context context) {
        try {
            ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            List<RunningTaskInfo> infos = manager.getRunningTasks(100);
            for (RunningTaskInfo runningTaskInfo : infos) {
                if (runningTaskInfo.topActivity.getClassName()
                        .equals("cooperation.qwallet.plugin.QWalletPluginProxyActivity")) {
                    return runningTaskInfo.numActivities;
                }
            }
            return 0;
        } catch (SecurityException e) {
            sendmsg(context, e.getMessage());
            return 0;
        }
    }

    public static String getVerName(Context context) {
        String verName = "";
        try {
            verName = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            sendmsg(context, "getVerName异常" + e.getMessage());
        }
        return verName;
    }
    public static String getWechatLoginId(Context context) {
        String loginId="";
        try {
            SharedPreferences sharedPreferences=context.getSharedPreferences("com.tencent.mm_preferences", 0);
            loginId = sharedPreferences.getString("login_user_name", "");
        } catch (Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
        return loginId;
    }
    /*
     * 启动一个app
     */
    public static void startAPP() {
        try {
            Intent intent = new Intent(CustomApplcation.getInstance().getContext(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            CustomApplcation.getInstance().getContext().startActivity(intent);
        } catch (Exception e) {
        }
    }

    /**
     * 将图片转换成Base64编码的字符串
     *
     * @param path
     * @return base64编码的字符串
     */
    public static String imageToBase64(String path) {
        if (TextUtils.isEmpty(path)) {
            return null;
        }
        InputStream is = null;
        byte[] data = null;
        String result = null;
        try {
            is = new FileInputStream(path);
            // 创建一个字符流大小的数组。
            data = new byte[is.available()];
            // 写入数组
            is.read(data);
            // 用默认的编码格式进行编码
            result = Base64.encodeToString(data, Base64.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != is) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        result = "\"data:image/gif;base64," + result + "\"";
        return result;
    }

    public static void sendAppMsg(String money, String mark, String type, Context context) {
        Intent broadCastIntent = new Intent();
        if (type.equals("alipay")||type.equals("alipaycheck")) {
            broadCastIntent.setAction(ALIPAYSTART_ACTION);
        } else if (type.equals("wechat")) {
            broadCastIntent.setAction(WECHATSTART_ACTION);
        } else if(type.equals("yunshanfu")){
            broadCastIntent.setAction(YUNSHANFUTART_ACTION);
        }else if (type.equals("qq")) {
            broadCastIntent.setAction(QQSTART_ACTION);
        }
        if(type.equals("alipaycheck")) {
            broadCastIntent.putExtra("type", "alipaycheck");
        }
        else{
            broadCastIntent.putExtra("type", "qrset");
        }
        broadCastIntent.putExtra("mark", mark);
        broadCastIntent.putExtra("money", money);
        context.sendBroadcast(broadCastIntent);
    }

    /*
     * 将时间戳转换为时间
     */
    public static String stampToDate(String s) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long lt = new Long(s);
        Date date = new Date(lt * 1000);
        res = simpleDateFormat.format(date);
        return res;
    }

    /**
     * 方法描述：判断某一应用是否正在运行
     *
     * @param context     上下文
     * @param packageName 应用的包名
     * @return true 表示正在运行，false表示没有运行
     */
    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
        if (list.size() <= 0) {
            return false;
        }
        for (ActivityManager.RunningTaskInfo info : list) {
            if (info.baseActivity.getPackageName().equals(packageName)) {
                return true;
            }
        }
        return false;
    }

    /*
     * 启动一个app
     */
    public static void startAPP(Context context, String appPackageName) {
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(appPackageName);
            context.startActivity(intent);
        } catch (Exception e) {
        }
    }

    public static void notify(final Context context, String type, final String no, String money, String mark, String dt) {


//        if (!mark.contains("|")) {
//            mark = CustomApplcation.temp_mark;
//        }


        //截取|字符串
        String str1 = "";
        String str2 = "";

        if(mark.contains("|")&&mark.contains(")")){
            str1 = mark.substring(mark.indexOf(")")+1, mark.indexOf("|"));
            str2=mark.substring(mark.indexOf("|")+1);
        }
        else if (mark.contains("|")) {
            str1 = mark.substring(0, mark.indexOf("|"));
            str2 = mark.substring(mark.indexOf("|") + 1);

        } else if(mark.contains("ORDER")&&mark.contains("QX")){
//                ORDER10054QX1000734
            str1 = mark.substring(5, mark.indexOf("Q"));
            str2 = mark.substring(mark.indexOf("X")+1);

        }else if (mark.contains("=姓")){
            mark=mark.substring(0, mark.indexOf("=姓"));
        }else {
            Log.i("错误", "mark有误");
        }


        String notifyurl = AbSharedUtil.getString(context, "notifyurl");
        String signkey = AbSharedUtil.getString(context, "signkey");
        if (no.equals("error")) {
            sendmsg(context, "定时发送通知...");
        } else {
            sendmsg(context, "订单" + mark + "定时发送通知...");
        }

        if (TextUtils.isEmpty(notifyurl) || TextUtils.isEmpty(signkey)) {
            sendmsg(context, "发送订单通知异常，定时URL为空");
            //update(no, "定时异步通知地址为空");
            update(no, "0");
            return;
        }
        String wxid = AbSharedUtil.getString(context, "wxid");
        HttpUtils httpUtils = new HttpUtils(15000);

        //String sign = MD5.md5(dt + mark + money + no + type + signkey);
        //String sign = MD5.md5(signkey + money + str1);
        RequestParams params = new RequestParams();
        //params.addBodyParameter("type", type);
        //params.addBodyParameter("mark", mark);
        // params.addBodyParameter("account_key", signkey);
        // params.addBodyParameter("amount", money);
        // params.addBodyParameter("out_trade_no", str1);

        params.addBodyParameter("dt", dt);
        params.addBodyParameter("no", no);
        params.addBodyParameter("money", money.replace("￥", ""));
        params.addBodyParameter("id", str1);
        params.addBodyParameter("order", str2);
        params.addBodyParameter("key", signkey);
        params.addBodyParameter("today_money", "");
        params.addBodyParameter("today_pens", "");


        if (!TextUtils.isEmpty(wxid)) {
            params.addBodyParameter("account", wxid);
        }
        //params.addBodyParameter("sign", sign);
        httpUtils.send(HttpMethod.POST, notifyurl, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                sendmsg(context, "定时发送异步通知异常，服务器异常" + "\n" + arg1);
                //update(no, arg1);
                update(no, "0");
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                if (result.contains("200")) {
                    sendmsg(context, "定时发送订单通知成功");
                    Log.i("22222Heart", result);
                    update(no, "1");
                } else {
                    sendmsg(context, "定时订单通知失败");
                    Log.i("22222Heart", result);
                    update(no, "0");
                }
                //update(no, result);
            }
        });
    }




 /*   public static void notifyHeart(final Context context) {
        Log.i("22222Heart", "心跳发送进行中");

        String wechat_key = AbSharedUtil.getString(context, "wechat_key");
        String alipay_key = AbSharedUtil.getString(context, "alipay_key");


        HttpUtils httpUtils = new HttpUtils(15000);
        RequestParams params = new RequestParams();

        params.addBodyParameter("service_wechat_key", wechat_key);
        params.addBodyParameter("service_alypay_key", alipay_key);

        httpUtils.send(HttpMethod.POST, CustomApplcation.base_url+CustomApplcation.heart_url, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                sendmsg(context, "发送心跳通知异常，服务器异常"+"\n" + arg1);
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                if (result.contains("200")) {
                    //sendmsg(context, "发送心跳通知成功");
                    Log.i("22222Heart", result);
                } else {
                    sendmsg(context, "发送心跳通知失败");
                    Log.i("22222Heart", result);
                }
            }
        });
    }
*/

    private static void update(String no, String result) {
        DBManager dbManager = new DBManager(CustomApplcation.getInstance().getContext());
        dbManager.updateOrder(no, result);
    }

    public static void sendmsg(Context context, String msg) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.putExtra("msg", msg);
        broadCastIntent.setAction(MSGRECEIVED_ACTION);
        context.sendBroadcast(broadCastIntent);
    }


    public static String getCookieStr(ClassLoader appClassLoader) {
        String cookieStr = "";
        // 获得cookieStr
        XposedHelpers.callStaticMethod(XposedHelpers.findClass(
                "com.alipay.mobile.common.transportext.biz.appevent.AmnetUserInfo", appClassLoader), "getSessionid");
        Context context = (Context) XposedHelpers.callStaticMethod(XposedHelpers.findClass(
                "com.alipay.mobile.common.transportext.biz.shared.ExtTransportEnv", appClassLoader), "getAppContext");
        if (context != null) {
            Object readSettingServerUrl = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("com.alipay.mobile.common.helper.ReadSettingServerUrl", appClassLoader),
                    "getInstance");
            if (readSettingServerUrl != null) {
                // String gWFURL = (String)
                // XposedHelpers.callMethod(readSettingServerUrl, "getGWFURL",
                // context);
                String gWFURL = ".alipay.com";
                cookieStr = (String) XposedHelpers.callStaticMethod(XposedHelpers
                                .findClass("com.alipay.mobile.common.transport.http.GwCookieCacheHelper", appClassLoader),
                        "getCookie", gWFURL);
            } else {
                sendmsg(context, "异常readSettingServerUrl为空");
            }
        } else {
            sendmsg(context, "异常context为空");
        }
        return cookieStr;
    }


    public static void getTradeInfo(final Context context, final String cookie) {
        long current = System.currentTimeMillis();
        //long s = current - 864000000;
        long s = current - 60000;
        String c = getCurrentDate();
        String url = "https://mbillexprod.alipay.com/enterprise/simpleTradeOrderQuery.json?beginTime=" + s
                + "&limitTime=" + current + "&pageSize=20&pageNum=1&channelType=ALL";
        HttpUtils httpUtils = new HttpUtils(15000);
        httpUtils.configResponseTextCharset("GBK");
        RequestParams params = new RequestParams();
        params.addHeader("Cookie", cookie);
        params.addHeader("Referer", "https://render.alipay.com/p/z/merchant-mgnt/simple-order.html?beginTime=" + c
                + "&endTime=" + c + "&fromBill=true&channelType=ALL");
        httpUtils.send(HttpMethod.GET, url, params, new RequestCallBack<String>() {

            @Override
            public void onFailure(HttpException arg0, String arg1) {
                sendmsg(context, "服务器异常" + arg1);
                Log.i("00000Heart", "商家服务信息失败：" + arg1);
            }

            @Override
            public void onSuccess(ResponseInfo<String> arg0) {
                String result = arg0.result;
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONObject res = jsonObject.getJSONObject("result");
                    JSONArray jsonArray = res.getJSONArray("list");
                    Log.i("00000Heart", "商家服务信息res：" + res);

                    if (jsonArray != null && jsonArray.length() > 0) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            String tradeNo = object.getString("tradeNo");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("tradeno", tradeNo);
                            broadCastIntent.putExtra("cookie", cookie);
                            broadCastIntent.setAction(TRADENORECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                        }
                        /*JSONObject object = jsonArray.getJSONObject(0);
                        String tradeNo = object.getString("tradeNo");
                        Log.i("00000Heart", "商家服务信息tradeNo："+tradeNo);
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("tradeno", tradeNo);
                        broadCastIntent.putExtra("cookie", cookie);
                        broadCastIntent.setAction(TRADENORECEIVED_ACTION);
                        context.sendBroadcast(broadCastIntent);*/
                    }

                } catch (Exception e) {
                    sendmsg(context, "getTradeInfo异常" + e.getMessage());
                    Log.i("00000Heart", "商家服务信息异常：" + e.getMessage());
                }

            }
        });
    }
    public static String getAlipayLoginId(ClassLoader classLoader) {
        String loginId="";
        try {
            Class<?> AlipayApplication = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication",
                    classLoader);
            Class<?> SocialSdkContactService = XposedHelpers
                    .findClass("com.alipay.mobile.personalbase.service.SocialSdkContactService", classLoader);
            Object instace = XposedHelpers.callStaticMethod(AlipayApplication, "getInstance");
            Object MicroApplicationContext = XposedHelpers.callMethod(instace, "getMicroApplicationContext");
            Object service = XposedHelpers.callMethod(MicroApplicationContext, "findServiceByInterface",
                    SocialSdkContactService.getName());
            Object MyAccountInfoModel = XposedHelpers.callMethod(service, "getMyAccountInfoModelByLocal");
            loginId = XposedHelpers.getObjectField(MyAccountInfoModel, "userId").toString();
//            loginId = XposedHelpers.getObjectField(MyAccountInfoModel, "loginId").toString();
        } catch (Exception e) {
        }
        return loginId;
    }
    public static String getCurrentDate() {
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String d = dateFormat.format(date);
        return d;
    }


    public static void updateAlipayCookie(Context context,String cookie){
        DBManager dbManager=new DBManager(context);
        if(dbManager.getConfig("cookie").equals("null")){
            dbManager.addConfig("cookie", cookie);
        }else{
            dbManager.updateConfig("cookie", cookie);
        }
    }

    public static String getAlipayCookie(Context context){
        DBManager dbManager=new DBManager(context);
        String cookie=dbManager.getConfig("cookie");
        return cookie;
    }
    public static String getcurrentTimeMillis(Context context){
        DBManager dbManager=new DBManager(context);
        return dbManager.getConfig("time");
    }
    public static String getOrderId() {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
        String newDate=sdf.format(new Date());
        String result="";
        Random random=new Random();
        for(int i=0;i<3;i++){
            result+=random.nextInt(10);
        }
        return newDate+result;
    }
    public static void startAlipayMonitor(final Context context){

        try {
            Timer timer=new Timer();
            TimerTask timerTask=new TimerTask() {
                @Override
                public void run() {
                    Calendar cc = Calendar.getInstance();//
                    int nowmi = cc.get(Calendar.MINUTE);
                    int nowhour = cc.get(Calendar.HOUR_OF_DAY);
                    int nowhour12 = cc.get(Calendar.HOUR);
                    if (nowhour12>9){
                        nowhour12=nowhour12-9;
                    }
                    //String nowmistr = String.valueOf(nowmi);
                    String nowminute=AbSharedUtil.getString(context, "nowminute");
                    int triggerTime = AbSharedUtil.getInt(context,"triggerTime") > 0 ? AbSharedUtil.getInt(context,"triggerTime") : 3;
                    //if (1==2){
                    //if (((nowhour>=8)&&((nowmi%10)==nowhour12)&&(nowminute.equals("0")))||((nowhour<8)&&(nowmi==nowhour12)&&(nowminute.equals("0")))){
//						if (((nowhour>=0)&&((nowmi%10)==nowhour12)&&(nowminute.equals("0")))||((nowhour<0)&&(nowmi==nowhour12)&&(nowminute.equals("0")))){
                    if (nowmi%triggerTime == 0 && nowminute.equals("0")){
                        AbSharedUtil.putString(context, "nowminute", "1");

                        sendmsg(context, "每间隔"+triggerTime+"分钟轮询获取订单数据...");


//							sendmsg(context, "轮询获取订单数据...");
                        final DBManager dbManager=new DBManager(context);
                        dbManager.saveOrUpdateConfig("time", System.currentTimeMillis()/1000+"");
                        final String cookie=PayHelperUtils.getAlipayCookie(context);
                        if(TextUtils.isEmpty(cookie) || cookie.equals("null")){
                            return;
                        }
                        long current = System.currentTimeMillis();
                        long s = current - 864000000;
                        String c = getCurrentDate();
                        String url = "https://mbillexprod.alipay.com/enterprise/simpleTradeOrderQuery.json?beginTime=" + s
                                + "&limitTime=" + current + "&pageSize=50&pageNum=1&channelType=ALL";
                        HttpUtils httpUtils = new HttpUtils(30000);
                        httpUtils.configResponseTextCharset("GBK");
                        RequestParams params = new RequestParams();
                        params.addHeader("Cookie", cookie);
                        params.addHeader("Referer", "https://render.alipay.com/p/z/merchant-mgnt/simple-order.html?beginTime=" + c
                                + "&endTime=" + c + "&fromBill=true&channelType=ALL");
                        httpUtils.send(HttpMethod.GET, url, params, new RequestCallBack<String>() {

                            @Override
                            public void onFailure(HttpException arg0, String arg1) {
                                sendmsg(context, "服务器异常" + arg1);
                                sendmsg(context, "数据异常");
                            }

                            @Override
                            public void onSuccess(ResponseInfo<String> arg0) {
                                try {
                                    String result = arg0.result;
                                    JSONObject jsonObject = new JSONObject(result);
                                    if(jsonObject.has("status")){
                                        String status=jsonObject.getString("status");
                                        if(!status.equals("deny")){
                                            JSONObject res = jsonObject.getJSONObject("result");
                                            JSONArray jsonArray = res.getJSONArray("list");
                                            if (jsonArray != null && jsonArray.length() > 0) {
                                                for (int i = 0; i < jsonArray.length(); i++) {
                                                    JSONObject object=jsonArray.getJSONObject(i);
                                                    String tradeNo=object.getString("tradeNo");
                                                    //sendmsg(context, "tradeNo is "+tradeNo);
                                                    if(!dbManager.isExistTradeNo(tradeNo)){
                                                        //if(isFirst){
                                                        //	 dbManager.addTradeNo(tradeNo,"1");
                                                        //}else{
                                                        if(!dbManager.isNotifyTradeNo(tradeNo)){
                                                            Intent broadCastIntent = new Intent();
                                                            sendmsg(context, "TRADENORECEIVED_ACTION tradeNo is "+tradeNo);
                                                            broadCastIntent.putExtra("tradeno", tradeNo);
                                                            broadCastIntent.putExtra("cookie", cookie);
                                                            broadCastIntent.setAction(TRADENORECEIVED_ACTION);
                                                            context.sendBroadcast(broadCastIntent);
                                                        }else{
                                                            //sendmsg(context, "该订单已Notify过了。tradeNo is "+tradeNo);

                                                        }
                                                        //}
                                                    }else{
                                                        //sendmsg(context, "该订单已处理过了。tradeNo is "+tradeNo);
                                                    }
                                                }
                                                isFirst=false;
                                            }
                                        }
                                    }
                                }catch (Exception e) {
                                    sendmsg(context, "startAlipayMonitor->>"+e.getMessage());
                                }
                                isFirst=false;
                            }
                        });

                    }else{
                        //if (((nowhour>=8)&&((nowmi%10)==nowhour12))||((nowhour<8)&&(nowmi==nowhour12))){
//							if ((nowhour>=0)&&((nowmi%10)==nowhour12)){
                        if (nowmi%-triggerTime == 0){
                        }else{
                            AbSharedUtil.putString(context, "nowminute", "0");
                        }

                    }

                    //}


                }
            };
            int _triggerTime=10;
            timer.schedule(timerTask, 0, _triggerTime*1000);
        } catch (Exception e) {
            sendmsg(context, "startAlipayMonitor->>"+e.getMessage());
        }
    }
}
