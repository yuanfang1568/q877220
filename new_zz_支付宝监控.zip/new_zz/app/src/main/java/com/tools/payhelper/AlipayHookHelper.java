package com.tools.payhelper;

import android.util.Log;

import de.robv.android.xposed.XposedHelpers;

/**
 * Created by Administrator on 2018/12/26.
 */

public class AlipayHookHelper {

    public static void rpcInvoke(Class<?> rpcClass, final AlipayRpcRunnable runnable, final String methodName, final Object... args) {
        try {
            ClassLoader classLoader = AliPayHook.mClassLoader;
            Class<?> AlipayApplication = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", classLoader);
            Object instace = XposedHelpers.callStaticMethod(AlipayApplication, "getInstance");
            Object MicroApplicationContext = XposedHelpers.callMethod(instace, "getMicroApplicationContext");
            Class<?> rpcServiceClass = XposedHelpers.findClass("com.alipay.mobile.framework.service.common.RpcService", classLoader);
            Object rpcService = XposedHelpers.callMethod(MicroApplicationContext, "findServiceByInterface", rpcServiceClass.getName());
            //-------------------------
            final Object rpcServiceObject = XposedHelpers.callMethod(rpcService, "getRpcProxy", rpcClass);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Object rpcRes = XposedHelpers.callMethod(rpcServiceObject, methodName, args);
                    runnable.rpcResult(rpcRes);
                }
            }).start();
        } catch (Exception ex) {
            Log.i("testBroadReceived:", "rpcInvoke Err:" + ex);
            ex.printStackTrace();
        }
    }

    /**
     * 获取订单列表
     *
     * @return
     */
    public static void getBillList(final AlipayRpcRunnable runnable) {
        try {
            final ClassLoader classLoader = AliPayHook.mClassLoader;
            final Class<?> rpcClass = XposedHelpers.findClass("com.alipay.mobilebill.biz.rpc.bill.v9.pb.BillListPBRPCService", classLoader);
            Log.i("testBroadReceived:", "rpcClass:" + rpcClass);
            Class<?> reqClass = XposedHelpers.findClass("com.alipay.mobilebill.common.service.model.pb.QueryListReq", classLoader);
            Log.i("testBroadReceived:", "reqClass:" + reqClass);
            final Object singleCreateReq = reqClass.newInstance();
            AlipayHookHelper.rpcInvoke(rpcClass, new AlipayRpcRunnable() {
                @Override
                public void rpcResult(Object obj) {
                    runnable.rpcResult(obj);
                }
            }, "query", singleCreateReq);


        } catch (Exception ex) {
            Log.i("testBroadReceived:", "getBillList Err:" + ex);
            ex.printStackTrace();
        }
    }

    public static void getSubBillList(final AlipayRpcRunnable runnable) {
        try {
            final ClassLoader classLoader = AliPayHook.mClassLoader;
            final Class<?> rpcClass = XposedHelpers.findClass("com.alipay.mobilebill.biz.rpc.bill.v9.BillListRPCService", classLoader);
            Log.i("testBroadReceived:", "rpcClass:" + rpcClass);
            Class<?> reqClass = XposedHelpers.findClass("com.alipay.mobilebill.common.service.model.req.QueryListReq", classLoader);
            Log.i("testBroadReceived:", "reqClass:" + reqClass);
            final Object singleCreateReq = reqClass.newInstance();
            AlipayHookHelper.rpcInvoke(rpcClass, new AlipayRpcRunnable() {
                @Override
                public void rpcResult(Object obj) {
                    runnable.rpcResult(obj);
                }
            }, "query", singleCreateReq);


        } catch (Exception ex) {
            Log.i("testBroadReceived:", "getSubBillList Err:" + ex);
            ex.printStackTrace();
        }
    }


    /**
     * 获取订单详情
     *
     * @return
     */
    public static void getBillDetail(String tradeNo, String bizType,final AlipayRpcRunnable runnable) {
        try {
            final ClassLoader classLoader = AliPayHook.mClassLoader;
            Class<?> rpcClass = XposedHelpers.findClass("com.alipay.mobilebill.biz.rpc.bill.v9.BillDetailRPCService", classLoader);
            Class<?> reqClass = XposedHelpers.findClass("com.alipay.mobilebill.core.model.billdetail.QueryDetailReq", classLoader);

            //alipay.mobile.bill.QuerySingleBillDetail
            //Log.i("testBroadReceived:", "reqClass:" + reqClass);
            final Object reqObject = reqClass.newInstance();

            reqClass.getField("tradeNo").set(reqObject, tradeNo);
            reqClass.getField("bizType").set(reqObject, bizType); //D_TRANSFER  TRADE

            AlipayHookHelper.rpcInvoke(rpcClass, new AlipayRpcRunnable() {
                @Override
                public void rpcResult(Object obj) {
                    runnable.rpcResult(obj);
                }
            }, "query", reqObject);
        } catch (Exception ex) {
            Log.i("testBroadReceived:", "getBillDetail Err:" + ex);
            ex.printStackTrace();
        }
    }
}
