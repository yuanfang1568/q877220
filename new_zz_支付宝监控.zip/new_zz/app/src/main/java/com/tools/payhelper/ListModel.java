package com.tools.payhelper;

import java.util.List;

public class ListModel {


    private List<BillListItemsBean> billListItems;

    public List<BillListItemsBean> getBillListItems() {
        return billListItems;
    }

    public void setBillListItems(List<BillListItemsBean> billListItems) {
        this.billListItems = billListItems;
    }

    public static class BillListItemsBean {
        /**
         * tagStatus : 0
         * month : 本月
         * unknownFieldsSerializedSize : 0
         * isAggregatedRec : false
         * recordType : MONTH
         * gmtCreate : 0
         * serializedSize : 69
         * statistics : 支出 ￥159,041.70    收入 ￥96,573.64
         * canDelete : false
         * contentRender : 0
         * consumeTitle : 收款-金达
         * oppositeLogo : https://t.alipayobjects.com/images/partner/TB1kJcrXhem.eJkUQusXXXs2FXa_[pixelWidth]x.png
         * actionParam : {"unknownFieldsSerializedSize":0,"serializedSize":203,"autoJumpUrl":"alipays://platformapi/startapp?appId=66666676&appClearTop=false&url=%2Fwww%2Findex.html%3FtradeNo%3D20181021200040011100250088040915%26bizType%3DD_TRANSFER%26appClearTop%3Dfalse%26startMultApp%3DYES","type":"APP"}
         * bizSubType : 1135
         * consumeFee : +0.01
         * bizInNo : 20181021200040011100250088040915
         * createTime : 00:31
         * consumeStatus : 2
         * createDesc : 今天
         * bizType : D_TRANSFER
         * categoryName : 其他
         */

        private long tagStatus;
        private String month;
        private long unknownFieldsSerializedSize;
        private boolean isAggregatedRec;
        private String recordType;
        private long gmtCreate;
        private long serializedSize;
        private String statistics;
        private boolean canDelete;
        private long contentRender;
        private String consumeTitle;
        private String oppositeLogo;
        private ActionParamBean actionParam;
        private String bizSubType;
        private String consumeFee;
        private String bizInNo;
        private String createTime;
        private String consumeStatus;
        private String createDesc;
        private String bizType;
        private String categoryName;

        public long getTagStatus() {
            return tagStatus;
        }

        public void setTagStatus(long tagStatus) {
            this.tagStatus = tagStatus;
        }

        public String getMonth() {
            return month;
        }

        public void setMonth(String month) {
            this.month = month;
        }

        public long getUnknownFieldsSerializedSize() {
            return unknownFieldsSerializedSize;
        }

        public void setUnknownFieldsSerializedSize(long unknownFieldsSerializedSize) {
            this.unknownFieldsSerializedSize = unknownFieldsSerializedSize;
        }

        public boolean isIsAggregatedRec() {
            return isAggregatedRec;
        }

        public void setIsAggregatedRec(boolean isAggregatedRec) {
            this.isAggregatedRec = isAggregatedRec;
        }

        public String getRecordType() {
            return recordType;
        }

        public void setRecordType(String recordType) {
            this.recordType = recordType;
        }

        public long getGmtCreate() {
            return gmtCreate;
        }

        public void setGmtCreate(long gmtCreate) {
            this.gmtCreate = gmtCreate;
        }

        public long getSerializedSize() {
            return serializedSize;
        }

        public void setSerializedSize(long serializedSize) {
            this.serializedSize = serializedSize;
        }

        public String getStatistics() {
            return statistics;
        }

        public void setStatistics(String statistics) {
            this.statistics = statistics;
        }

        public boolean isCanDelete() {
            return canDelete;
        }

        public void setCanDelete(boolean canDelete) {
            this.canDelete = canDelete;
        }

        public long getContentRender() {
            return contentRender;
        }

        public void setContentRender(long contentRender) {
            this.contentRender = contentRender;
        }

        public String getConsumeTitle() {
            return consumeTitle;
        }

        public void setConsumeTitle(String consumeTitle) {
            this.consumeTitle = consumeTitle;
        }

        public String getOppositeLogo() {
            return oppositeLogo;
        }

        public void setOppositeLogo(String oppositeLogo) {
            this.oppositeLogo = oppositeLogo;
        }

        public ActionParamBean getActionParam() {
            return actionParam;
        }

        public void setActionParam(ActionParamBean actionParam) {
            this.actionParam = actionParam;
        }

        public String getBizSubType() {
            return bizSubType;
        }

        public void setBizSubType(String bizSubType) {
            this.bizSubType = bizSubType;
        }

        public String getConsumeFee() {
            return consumeFee;
        }

        public void setConsumeFee(String consumeFee) {
            this.consumeFee = consumeFee;
        }

        public String getBizInNo() {
            return bizInNo;
        }

        public void setBizInNo(String bizInNo) {
            this.bizInNo = bizInNo;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getConsumeStatus() {
            return consumeStatus;
        }

        public void setConsumeStatus(String consumeStatus) {
            this.consumeStatus = consumeStatus;
        }

        public String getCreateDesc() {
            return createDesc;
        }

        public void setCreateDesc(String createDesc) {
            this.createDesc = createDesc;
        }

        public String getBizType() {
            return bizType;
        }

        public void setBizType(String bizType) {
            this.bizType = bizType;
        }

        public String getCategoryName() {
            return categoryName;
        }

        public void setCategoryName(String categoryName) {
            this.categoryName = categoryName;
        }

        public static class ActionParamBean {
            /**
             * unknownFieldsSerializedSize : 0
             * serializedSize : 203
             * autoJumpUrl : alipays://platformapi/startapp?appId=66666676&appClearTop=false&url=%2Fwww%2Findex.html%3FtradeNo%3D20181021200040011100250088040915%26bizType%3DD_TRANSFER%26appClearTop%3Dfalse%26startMultApp%3DYES
             * type : APP
             */

            private long unknownFieldsSerializedSize;
            private long serializedSize;
            private String autoJumpUrl;
            private String type;

            public long getUnknownFieldsSerializedSize() {
                return unknownFieldsSerializedSize;
            }

            public void setUnknownFieldsSerializedSize(long unknownFieldsSerializedSize) {
                this.unknownFieldsSerializedSize = unknownFieldsSerializedSize;
            }

            public long getSerializedSize() {
                return serializedSize;
            }

            public void setSerializedSize(long serializedSize) {
                this.serializedSize = serializedSize;
            }

            public String getAutoJumpUrl() {
                return autoJumpUrl;
            }

            public void setAutoJumpUrl(String autoJumpUrl) {
                this.autoJumpUrl = autoJumpUrl;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }
        }
    }
}
