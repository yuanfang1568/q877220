package com.tools.payhelper;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.tools.payhelper.utils.AbSharedUtil;

public class SettingActivity extends Activity implements OnClickListener {

    private EditText et_returnurl, et_notifyurl, et_signkey, et_wxid;
    private EditText et_device, et_wechat, et_alipay, et_tenpay;
    private Button bt_save, bt_back;
    private RelativeLayout rl_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_setting);
        et_returnurl = (EditText) findViewById(R.id.returnurl);
        et_notifyurl = (EditText) findViewById(R.id.notifyurl);
        et_signkey = (EditText) findViewById(R.id.signkey);
        et_wxid = (EditText) findViewById(R.id.et_wxid);

        et_device = (EditText) findViewById(R.id.et_device_key);
        et_wechat = (EditText) findViewById(R.id.et_wechat_key);
        et_alipay = (EditText) findViewById(R.id.et_alipay_key);
        et_tenpay = (EditText) findViewById(R.id.et_tenpay_key);


        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "returnurl"))) {
            et_returnurl.setText(AbSharedUtil.getString(getApplicationContext(), "returnurl"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "notifyurl"))) {
            et_notifyurl.setText(AbSharedUtil.getString(getApplicationContext(), "notifyurl"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "signkey"))) {
            et_signkey.setText(AbSharedUtil.getString(getApplicationContext(), "signkey"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "account"))) {
            et_wxid.setText(AbSharedUtil.getString(getApplicationContext(), "account"));
        }

        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "device_key"))) {
            et_device.setText(AbSharedUtil.getString(getApplicationContext(), "device_key"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "wechat_key"))) {
            et_wechat.setText(AbSharedUtil.getString(getApplicationContext(), "wechat_key"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "alipay_key"))) {
            et_alipay.setText(AbSharedUtil.getString(getApplicationContext(), "alipay_key"));
        }
        if (!TextUtils.isEmpty(AbSharedUtil.getString(getApplicationContext(), "tenpay_key"))) {
            et_tenpay.setText(AbSharedUtil.getString(getApplicationContext(), "tenpay_key"));
        }

        bt_save = (Button) findViewById(R.id.save);
        bt_back = (Button) findViewById(R.id.back);
        rl_back = (RelativeLayout) findViewById(R.id.rl_back);
        bt_back.setOnClickListener(this);
        bt_save.setOnClickListener(this);
        rl_back.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.save:
                String returnurl = et_returnurl.getText().toString();
                if (!TextUtils.isEmpty(returnurl)) {
                    AbSharedUtil.putString(getApplicationContext(), "returnurl", returnurl);
                }

                String notifyurl = et_notifyurl.getText().toString();
                if (!TextUtils.isEmpty(notifyurl)) {
                    AbSharedUtil.putString(getApplicationContext(), "notifyurl", notifyurl);
                }

                String signkey = et_signkey.getText().toString();
                if (!TextUtils.isEmpty(signkey)) {
                    AbSharedUtil.putString(getApplicationContext(), "signkey", signkey);
                }

                String wxid = et_wxid.getText().toString();
                if (!TextUtils.isEmpty(wxid)) {
                    AbSharedUtil.putString(getApplicationContext(), "account", wxid);
                }


                String device = et_device.getText().toString();
                if (!TextUtils.isEmpty(device)) {
                    AbSharedUtil.putString(getApplicationContext(), "device_key", device);
                }

                String wechat = et_wechat.getText().toString();
                if (!TextUtils.isEmpty(wechat)) {
                    AbSharedUtil.putString(getApplicationContext(), "wechat_key", wechat);
                }

                String alipay = et_alipay.getText().toString();
                if (!TextUtils.isEmpty(alipay)) {
                    AbSharedUtil.putString(getApplicationContext(), "alipay_key", alipay);
                }
                String tenpay = et_tenpay.getText().toString();
                if (!TextUtils.isEmpty(tenpay)) {
                    AbSharedUtil.putString(getApplicationContext(), "tenpay_key", tenpay);
                }
                Toast.makeText(this,"配置保存成功",Toast.LENGTH_SHORT).show();
                finish();
                break;
            case R.id.back:
                finish();
                break;
            case R.id.rl_back:
                finish();
                break;
            default:
                break;
        }
    }
}
