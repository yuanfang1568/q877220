package com.tools.payhelper;

import android.content.Context;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tools.payhelper.utils.AbSharedUtil;
import com.tools.payhelper.utils.JsonHelper;
import com.tools.payhelper.utils.LogToFile;
import com.tools.payhelper.utils.PayHelperUtils;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import static com.tools.payhelper.CustomApplcation.alipayMaxSet;

public class SocketClient extends WebSocketClient {
    SocketListener socketListener;


    static Vector<String> payListOrder=new Vector<String>();

    static Vector<String> withDrawPayListOrder=new Vector<String>();
    public void setSocketListener(SocketListener socketListener) {

        this.socketListener = socketListener;
    }
    public static boolean isValidLong(String str) {
        try {
//            String a="132.456";
            float b = Float.parseFloat(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    /**
     * @param args
     * @throws URISyntaxException
     */
    public static void main(String[] args) throws URISyntaxException {
//        WebSocketClient client = new SocketClient(new URI("ws://58.82.250.200:9092/"));
//        client.connect();

//        String str2 = "可用余额 1元";
//        float d = getDoubleValue(str2);
//        System.out.println(">>"+d);
        String test="123456";
        System.out.println(test.substring(5,6));

    }
    Context context;
    public SocketClient(Context context, URI serverUri) {
        super(serverUri);
        this.context=context;

        System.out.println("初始化通道" + CustomApplcation.base_socketurl);
        LogToFile.e("日志", "通道初始化");
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        System.out.println("打开通道");
    }

    public static long nowTime=0;
    @Override
    public void onMessage(String message) {

        try {
            System.out.println("接受消息" + JsonHelper.isJson(message) + "   " + message);
            LogToFile.e("日志", "通道接受消息"+message);

            //解析指令，然后请求http
            if (JsonHelper.isJson(message)) {
                //解析type
                JSONObject jsonObj = JSON.parseObject(message);
                String type = jsonObj.getString("type");
                if (type != null) {
                    if (type.equals("init") || type.equals("login")) {
                        String clientid = jsonObj.getString("client_id");
                        if (socketListener != null) {
                            socketListener.init_login(clientid);
                        }
                    } else if (type.equals("paytype")) {
                        LogToFile.e("支付流程", "收到所有消息"+message);

                        nowTime=new Date().getTime();
                        String mark = jsonObj.getString("mark");
                        String money = jsonObj.getString("money");
                        String paytype = jsonObj.getString("paytype");
                        String keyid = jsonObj.getString("key_id");

                        if(payListOrder.contains(mark+paytype)){
                            System.out.println("不接受消息，paytype发出支付请求"+mark+paytype);
                            return;
                        }else{
                            payListOrder.add(mark+paytype);
                            if (socketListener != null) {
                                System.out.println("接受消息，paytype发出支付请求"+mark+paytype);
                                socketListener.getpay(mark, money, paytype, keyid,"");
                            }
                        }
                    }//{"type":"withdraw","pattern":0,"pw":317614,"time":1542033873,"key_id":"4AB6B9C0CE1359EC5C","paytype":"alipay"}
                    else if (type.equals("alipaycheck")) {
                        LogToFile.e("支付流程", "收到所有消息"+message);

                        nowTime=new Date().getTime();
                        String mark = jsonObj.getString("mark");
                        String money = jsonObj.getString("money");
                        String paytype = jsonObj.getString("paytype");
                        String keyid = jsonObj.getString("key_id");
                        String uid = jsonObj.getString("uid");

                        if(payListOrder.contains(mark+paytype)){
                            System.out.println("不接受消息，paytype发出支付请求"+mark+paytype);
                            return;
                        }else{
                            payListOrder.add(mark+paytype);
                            if (socketListener != null) {
                                System.out.println("接受消息，paytype发出支付请求"+mark+paytype);
                                socketListener.getpay(mark, money, paytype, keyid,uid);
                            }
                        }
                    }
                    else if(type.equals("withdraw")){
                        String alipay_withdrawid = jsonObj.getString("time");
                        String alipay_keyid = jsonObj.getString("key_id");
                        String alipay_pw = jsonObj.getString("pw");
                        if(withDrawPayListOrder.contains(alipay_withdrawid)){
                            System.out.println("重复提现，不处理");
                            return;
                        }else{
                            System.out.println("处理提现");
                            withDrawPayListOrder.add(alipay_withdrawid);

                            String ali_key = "";
                            if (!TextUtils.isEmpty(AbSharedUtil.getString(context, "alipay_key"))) {
                                ali_key = (AbSharedUtil.getString(context, "alipay_key"));
                            }

                            if(alipay_keyid.equals(ali_key)){
                                System.out.println("处理提现");
//                                if (socketListener != null) {
//                                    socketListener.withdrawAlipay(alipay_pw);
//                                }
                            }else{
                                System.out.println("id不符合，不处理提现");
                            }
                        }
                    }else if(type.equals("ping")){
                        System.out.println("回应在线");
                        send("{\"type\":\"ping\"}");
                    }else if(type.equals("set_max_amount")){
                        //增加过滤，不是当前的微信你支付宝key的不处理
                        System.out.println("收款上限设置");//查询余额，后台的设置的额金额大于支付宝账号的，运行，小于，关闭网段
                        String alipay_max = jsonObj.getString("alipay_max_amount");
                        String alipay_key_id = jsonObj.getString("alipay_key_id");

                        String ali_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(context, "alipay_key"))) {
                            ali_key = (AbSharedUtil.getString(context, "alipay_key"));
                        }

                        if(alipay_key_id==null){
                            //不处理
                            System.out.println("限额id为空，不处理");
                        }else{
                            if(ali_key.equals(alipay_key_id)){
                                System.out.println("限额id符合，处理");
                                if(alipay_max==null){
                                    //不限制
                                    CustomApplcation.alipayMaxSet=false;
                                    CustomApplcation.alipayMaxSetNum=0;
                                }else if(isValidLong(alipay_max+"")){
                                    if(Float.parseFloat(alipay_max)==0){
                                        //不限制
                                        CustomApplcation.alipayMaxSet=false;
                                        CustomApplcation.alipayMaxSetNum=0;
                                    }else{
                                        //限制支付宝金额
                                        CustomApplcation.alipayMaxSet=true;
                                        CustomApplcation.alipayMaxSetNum=Float.parseFloat(alipay_max);
                                        //回调过去，条件适合，关闭当前支付宝通道
                                        if (socketListener != null) {
                                            socketListener.checkAlipayBalance(CustomApplcation.alipayMaxSetNum);
                                        }
                                    }

                                }else{
                                    //不限制，
                                    CustomApplcation.alipayMaxSet=false;
                                    CustomApplcation.alipayMaxSetNum=0;
                                }
                            }else{
                                System.out.println("限额id不符合，不处理");
                            }
                        }



                        String wechat_max = jsonObj.getString("wechat_max_amount");
                        String wechat_key_id = jsonObj.getString("wechat_key_id");

                        String wechat_key = "";
                        if (!TextUtils.isEmpty(AbSharedUtil.getString(context, "wechat_key"))) {
                            wechat_key = (AbSharedUtil.getString(context, "wechat_key"));
                        }
                        if(wechat_key_id==null){
                            //不处理
                            System.out.println("微信限额id为空，不处理");
                        }else{
                            if(wechat_key.equals(wechat_key_id)){
                                System.out.println("微信限额id符合，处理");
                                if(wechat_max==null){
                                    //不限制
                                    CustomApplcation.wecahtMaxSet=false;
                                    CustomApplcation.wechatMaxSetNum=0;
                                }else if(isValidLong(wechat_max+"")){
                                    if(Float.parseFloat(wechat_max)==0){
                                        //不限制
                                        CustomApplcation.wecahtMaxSet=false;
                                        CustomApplcation.wechatMaxSetNum=0;
                                    }else{
                                        //限制金额
                                        CustomApplcation.wecahtMaxSet=true;
                                        CustomApplcation.wechatMaxSetNum=Float.parseFloat(wechat_max);
                                        //回调过去，条件适合，关闭当前微信
                                        if (socketListener != null) {
                                            socketListener.chetWechatBalance(CustomApplcation.wechatMaxSetNum);
                                        }
                                    }
                                }else {
                                    //不限制
                                    CustomApplcation.wecahtMaxSet=false;
                                    CustomApplcation.wechatMaxSetNum=0;
                                }
                            }else{
                                System.out.println("微信限额id不符合，不处理");
                            }
                        }



                        System.out.println("收款设置结果：alipaySet:"+CustomApplcation.alipayMaxSet+" alipayNum:"+CustomApplcation.alipayMaxSetNum+" "+
                                "weichatSet:"+CustomApplcation.wecahtMaxSet+"  wechatNum:"+CustomApplcation.wechatMaxSetNum);
                    }else if(type.equals("set_wechat_balance_reset")){
                        //微信清零余额，目前没有查询微信真实的值
                        if (socketListener != null) {
                            socketListener.chetWechatBalanceReset();
                        }
                    }

                }
                //微信收到清零指令就清除
            }
            //回调

        } catch (Exception e) {
            e.printStackTrace();
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("Connection closed by " + (remote ? "remote peer" : "us"));
        System.out.println("picher_log" + "通道关闭");
        LogToFile.e("日志", "通道关闭");
        CustomApplcation.error_count++;
        if (socketListener != null) {
            socketListener.closed(CustomApplcation.error_count);
        }
    }

    @Override
    public void onError(Exception ex) {
        ex.printStackTrace();
        LogToFile.e("日志", "通道连接错误");
        System.out.println("连接错误");
        PayHelperUtils.sendmsg(context, ex.getMessage()+" \n "+CustomApplcation.base_socketurl);
    }


    /**
     * 解析字符串获得双精度型数值，
     * @param str
     * @return
     */
    public static float getDoubleValue(String str)
    {
        float d = 0;

        if(str!=null && str.length()!=0)
        {
            StringBuffer bf = new StringBuffer();

            char[] chars = str.toCharArray();
            for(int i=0;i<chars.length;i++)
            {
                char c = chars[i];
                if(c>='0' && c<='9')
                {
                    bf.append(c);
                }
                else if(c=='.')
                {
                    if(bf.length()==0)
                    {
                        continue;
                    }
                    else if(bf.indexOf(".")!=-1)
                    {
                        break;
                    }
                    else
                    {
                        bf.append(c);
                    }
                }
                else
                {
                    if(bf.length()!=0)
                    {
                        break;
                    }
                }
            }
            try
            {
                d = Float.parseFloat(bf.toString());
            }
            catch(Exception e)
            {}
        }

        return d;
    }




}
