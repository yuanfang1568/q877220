package com.tools.payhelper;

public interface SocketListener {
    public void init_login(String clientid);
    public void getpay(String mark, String money, String paytype, String keyid,String uid );
    public void closed(int nowcount);

    public void checkAlipayBalance(float balance);
    public void chetWechatBalance(float balance);

    public void chetWechatBalanceReset();

    public void withdrawAlipay(String pw);
}
