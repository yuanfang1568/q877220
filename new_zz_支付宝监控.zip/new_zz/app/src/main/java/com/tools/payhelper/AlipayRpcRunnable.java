package com.tools.payhelper;

/**
 * Created by Administrator on 2018/12/26.
 */

public class AlipayRpcRunnable{

    public void rpcResult(Object obj){

        //解析参数----
    }
}
