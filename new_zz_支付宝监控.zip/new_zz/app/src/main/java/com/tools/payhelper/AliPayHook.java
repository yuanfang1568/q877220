package com.tools.payhelper;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Base64;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.tools.payhelper.utils.PayHelperUtils;
import com.tools.payhelper.utils.StringUtils;
import com.tools.payhelper.v134.ChatMsgObjCon;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * @author suxia_3vuneo4
 */

public class AliPayHook {
    public static String BACK_HOME_ACTION_START = "com.tools.payhelper.backstartapp";
    public static String SAVEALIPAYCOOKIE_ACTION = "com.tools.payhelper.savealipaycookie";
    public static String START_ACTION = "com.tools.payhelper.withdraw";

    public static String BALANCERECEIVED_ACTION = "com.tools.payhelper.balacnereceived";

    public static String BILLRECEIVED_ACTION = "com.tools.payhelper.billreceived";
    public static String QRCODERECEIVED_ACTION = "com.tools.payhelper.qrcodereceived";

    public static String tempCook = "";

    public static List<Bundle> bundleList = new ArrayList<>();
    private static Intent envIntent;
    private static Context mContext;
    public static ClassLoader mClassLoader;
    private static boolean doNext = true;
    public String mMark = "";
    public String mMoney = "";
    public String mNo = "";
    public String mTUserid = "";

    Timer timer = new Timer();
    TimerTask task = new TimerTask() {
        @Override
        public void run() {
            //refreshParams();
//            PayHelperUtils.sendmsg(mContext,">>>>"+mSignkey+mAccount+mNotifyurl+mUserid);
            if (bundleList.size() == 0 || !doNext)
                return;
            doNext = false;
            envIntent.putExtra("app_id", "88886666");
            envIntent.putExtra("mExtras", bundleList.get(0));
            envIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            mContext.startActivity(envIntent);
        }
    };
    Handler handler;

    public static void delectContact(String userid) {
    /*    HandleRelationReq handleRelationReq = new HandleRelationReq();
        handleRelationReq.targetUserId = profileSettingActivity.k.userId;
        handleRelationReq.bizType = "2";
        handleRelationReq.alipayAccount = profileSettingActivity.k.account;
        BaseResult handleRelation = profileSettingActivity.u.handleRelation(handleRelationReq);*/
        Object contactAccount = com.tools.payhelper.v134.Tools.getContactAccount(mClassLoader, userid);

        Object handleRelationReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.req.HandleRelationReq", mClassLoader));
        String userId = XposedHelpers.getObjectField(contactAccount, "userId") + "";
        String account = XposedHelpers.getObjectField(contactAccount, "account") + "";
        XposedHelpers.setObjectField(handleRelationReq, "targetUserId", userId);
        XposedHelpers.setObjectField(handleRelationReq, "alipayAccount", account);
        XposedHelpers.setObjectField(handleRelationReq, "bizType", "2");
        Object service = com.tools.payhelper.v134.Tools.getRpcService(com.tools.payhelper.v134.Tools.getAlipayApplication(mClassLoader));
        XposedBridge.log("service " + service);
        Object alipayRelationManageService = XposedHelpers.callMethod(service, "getRpcProxy", XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.rpc.AlipayRelationManageService", mClassLoader));
        Object re = XposedHelpers.callMethod(alipayRelationManageService, "handleRelation", handleRelationReq);
        XposedBridge.log("删除好友结果" + JSON.toJSONString(re));
    }

    public static void sendMsg(String userid, String content) {
        final Class<?> msgFac = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", mClassLoader);

        XposedHelpers.callStaticMethod(msgFac, "createTextMsg", userid, "1", content, null, null, false);
    }

    public void hook(final ClassLoader classLoader, final Context context) {
        securityCheckHook(classLoader);
        hookActivityCreateFinish(context, classLoader);
        mContext = context;
        mClassLoader = classLoader;
        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                final String userid = (String) msg.obj;
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        delectContact(userid);
                    }
                }).start();

            }
        };
        try {
            Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.TradeDao", classLoader);
            XposedBridge.hookAllMethods(insertTradeMessageInfo, "insertMessageInfo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        Log.i("8888Heart", "进来了接受订单通知广播11");
                        XposedBridge.log("======个人收款start=========");

                        //获取content字段
//            			String content=(String) XposedHelpers.getObjectField(param.args[0], "content");
//            			XposedBridge.log(content);
                        //获取全部字段
                        Object object = param.args[0];
                        String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                        Log.i("8888Heart", "支付宝支付" + MessageInfo);
                        XposedBridge.log(MessageInfo);
                        String content = StringUtils.getTextCenter(MessageInfo, "content='", "'");
                        Log.i("8888Heart", "进来了接受订单通知广播88" + content);
                        if (content.contains("二维码收款") || content.contains("收到一笔转账") || content.contains("收款金额") || content.contains("收款到账")) {
                            Log.i("#####", "这是什么玩意进来的? 转账?");
                            Log.i("8888Heart", "进来了接受订单通知广播44");
                            JSONObject jsonObject = new JSONObject(content);
                            String money = jsonObject.getString("content");
                            String mark = jsonObject.getString("assistMsg2");
                            String tradeNo = StringUtils.getTextCenter(MessageInfo, "tradeNO=", "&");
                            XposedBridge.log("收到支付宝支付订单：" + tradeNo + "==" + money + "==" + mark);
                            Log.i("8888Heart", "收到支付宝支付订单" + tradeNo + "==" + money + "==" + mark);

                            ///去查询详情
                            //替换
                            replaceDetailPage(context);
                            //固码详情
                            billDetail(context, tradeNo, "D_TRANSFER", money, mark);


                            System.out.println("支付宝日志：个人收到支付结果 mark=" + mark + "  ");
                        }
                        XposedBridge.log("======end=========");
                    } catch (Exception e) {
                        Log.i("8888Heart", "进来了接受订单通知广播22");
                        XposedBridge.log(e.getMessage());
                    }
                    super.beforeHookedMethod(param);
                }
            });


            Class<?> insertServiceMessageInfo = XposedHelpers.findClass("com.alipay.android.phone.messageboxstatic.biz.dao.ServiceDao", classLoader);
            XposedBridge.hookAllMethods(insertServiceMessageInfo, "insertMessageInfo", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        XposedBridge.log("======海豚支付宝商家服务订单start=========");

                        //更新cookie
                        Intent cookieBroadCastIntent = new Intent();
                        String alipaycookie = PayHelperUtils.getCookieStr(classLoader);
                        cookieBroadCastIntent.putExtra("alipaycookie", alipaycookie);
                        cookieBroadCastIntent.setAction(SAVEALIPAYCOOKIE_ACTION);
                        context.sendBroadcast(cookieBroadCastIntent);

                        Object object = param.args[0];
                        String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                        Log.i("6666Heart", "支付宝支付" + MessageInfo);
                        String content = StringUtils.getTextCenter(MessageInfo, "extraInfo='", "'").replace("\\", "");
                        Log.i("666Heart", "进来了商家订单通知广播" + content);
                        XposedBridge.log(content);
                        if (content.contains("店员通") || content.contains("收钱到账") || content.contains("收款到账")) {
                            Log.i("6666Heart", "进来了接受商家订单通知广播6666");
                            String money = StringUtils.getTextCenter(content, "mainAmount\":\"", "\",\"mainTitle");
                            String mark = StringUtils.getTextCenter(content, "gmtCreate\":", ",gmtValid");
                            String no = PayHelperUtils.getOrderId();
                            Intent broadCastIntent = new Intent();
                            Log.i("#####", "这是什么玩意进来的? 收款码?" + no);


                            getBillList(context, money);



                            /*broadCastIntent.putExtra("bill_no", no);
                            broadCastIntent.putExtra("bill_money", money);
                            broadCastIntent.putExtra("bill_mark", mark);
                            broadCastIntent.putExtra("bill_type", "alipay");
                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);*/
                            XposedBridge.log("收到商家订单：" + no + "==" + money);

                        }
                        XposedBridge.log("======海豚支付宝商家服务订单end=========");
                    } catch (Exception e) {
                        PayHelperUtils.sendmsg(context, e.getMessage());
                    }
                    super.beforeHookedMethod(param);
                }
            });


            // hook设置金额和备注的onCreate方法，自动填写数据并点击
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("Hook支付宝开始.........");
                    Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                    final Object jinErView = jinErField.get(param.thisObject);
                    Field beiZhuField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                    final Object beiZhuView = beiZhuField.get(param.thisObject);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    String mark = intent.getStringExtra("mark");
                    String money = intent.getStringExtra("money");

                    //设置支付宝金额和备注
                    XposedHelpers.callMethod(jinErView, "setText", money);
                    XposedHelpers.callMethod(beiZhuView, "setText", mark);


                    //点击确认
                    Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "e");
                    final Button quRenButton = (Button) quRenField.get(param.thisObject);
                    quRenButton.performClick();
                    System.out.println("支付宝日志：调用生成二维码 mark=" + mark);


                }
            });

            // hook获得二维码url的回调方法
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", classLoader, "a",
                    XposedHelpers.findClass("com.alipay.transferprod.rpc.result.ConsultSetAmountRes", classLoader), new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                            Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "g");
                            String money = (String) moneyField.get(param.thisObject);

                            Field markField = XposedHelpers.findField(param.thisObject.getClass(), "c");
                            Object markObject = markField.get(param.thisObject);
                            String mark = (String) XposedHelpers.callMethod(markObject, "getUbbStr");

                            Object consultSetAmountRes = param.args[0];
                            System.out.println("当前数据长度：" + param.args.length);
                            Field consultField = XposedHelpers.findField(consultSetAmountRes.getClass(), "qrCodeUrl");
                            String payurl = (String) consultField.get(consultSetAmountRes);

                            Field consultField1 = XposedHelpers.findField(consultSetAmountRes.getClass(), "codeId");
                            String codeId = (String) consultField1.get(consultSetAmountRes);

                            Field consultField2 = XposedHelpers.findField(consultSetAmountRes.getClass(), "printQrCodeUrl");
                            String printQrCodeUrl = (String) consultField2.get(consultSetAmountRes);

                            System.out.println("当前数据corid：" + codeId + "   " + printQrCodeUrl);

                            XposedBridge.log(money + "  " + mark + "  " + payurl);
                            XposedBridge.log("调用增加数据方法==>支付宝");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("mark", mark);
                            broadCastIntent.putExtra("type", "alipay");
                            broadCastIntent.putExtra("payurl", payurl);
                            broadCastIntent.setAction(QRCODERECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);
                            System.out.println("支付宝日志：捕捉到支付宝二维码 mark=" + mark + "  " + payurl);
                        }
                    });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }


        timer.schedule(task, 0, 1000);

        try {

            //消息
            Class<?> chatCallback = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.data.ChatDataSyncCallback", classLoader);
            Class<?> chatDao = XposedHelpers.findClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.data.ChatMsgDaoOp", classLoader);

            Class ChatMsgObj = classLoader.loadClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.ChatMsgObj");
            Class SyncChatMsgModel = classLoader.loadClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.SyncChatMsgModel");
            XposedHelpers.findAndHookConstructor(ChatMsgObj, String.class, SyncChatMsgModel, new ChatMsgObjCon(classLoader, context));//针对红包的


            final Class<?> syncmsg = XposedHelpers.findClass("com.alipay.mobile.rome.longlinkservice.syncmodel.SyncMessage", classLoader);
            final Class<?> msgFac = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", classLoader);
            final Class<?> sendMsg = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.request.BaseChatRequest", classLoader);
            final Class<?> redEn = XposedHelpers.findClass("com.alipay.mobile.redenvelope.proguard.n.a", classLoader);
            final Class<?> chatP = XposedHelpers.findClass("com.alipay.mobile.chatapp.ui.PersonalChatMsgActivity_", classLoader);
            final Class<?> chatB = XposedHelpers.findClass("com.alipay.mobile.chatapp.ui.ChatMsgBaseActivity", classLoader);
            final Class<?> snsCou = XposedHelpers.findClass("com.alipay.android.phone.discovery.envelope.get.SnsCouponDetailActivity", classLoader);
            final Class<?> giftCrow = XposedHelpers.findClass("com.alipay.giftprod.biz.crowd.gw.result.GiftCrowdDetailResult", classLoader);
            final Class<?> wire = XposedHelpers.findClass("com.squareup.wire.Wire", classLoader);
            final Class<?> msgPModel = XposedHelpers.findClass("com.alipay.mobilechat.core.model.message.MessagePayloadModel", classLoader);
            final Class<?> A = XposedHelpers.findClass("com.alipay.android.phone.discovery.envelope.ui.util.a", classLoader);
            final Class<?> resvdetail = XposedHelpers.findClass("com.alipay.android.phone.discovery.envelope.received.ReceivedDetailActivity", classLoader);
            XposedHelpers.findAndHookMethod(chatP, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    Bundle bundle = intent.getExtras();
                    Set<String> set = bundle.keySet();
                    for (String string : set) {
                        XposedBridge.log("key=" + string + "--value=" + bundle.get(string));
                    }

                }
            });
            XposedBridge.hookAllMethods(msgFac, "createCommonMessage", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log(" createCommonMessage " + Arrays.toString(param.args));
                    if (param.args.length >= 4) {
                        Object o = param.args[3];
                        if (o.getClass().toString().contains("CommonMediaInfo")) {
                            XposedBridge.log("CommonMediaInfo " + JSON.toJSONString(o));
                        }
                    }
                }
            });
            XposedHelpers.findAndHookMethod(chatCallback, "onReceiveMessage", syncmsg,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            Object object = param.args[0];
                            JSONArray msgArr = new JSONArray(syncmsg.getField("msgData").get(object).toString());
                            JSONObject msg1 = msgArr.getJSONObject(0);
                            String pl = msg1.getString("pl");
                            Object wireIns = XposedHelpers.newInstance(wire, new ArrayList<Class>());
                            Object decode_pl = XposedHelpers.callMethod(wireIns, "parseFrom", Base64.decode(pl, 0), msgPModel);
                            String decode_pl_str = JSON.toJSONString(decode_pl);
                            com.alibaba.fastjson.JSONObject decode_pl_json = JSON.parseObject(decode_pl_str);
                            String biz_type = decode_pl_json.getString("biz_type");
                            String content = decode_pl_json.getJSONObject("template_data").getString("m");
                            String userid = decode_pl_json.getString("from_u_id");
                            String link = decode_pl_json.getString("link") + "#";
                            mTUserid = decode_pl_json.getString("to_u_id");

                            boolean universalDetail = true;
                            String socialCardCMsgId = decode_pl_json.getString("client_msg_id");
                            String target = "groupPre";
                            String schemeMode = "portalInside";
                            String prevBiz = "chat";
                            String bizType = "CROWD_COMMON_CASH";
                            String sign = StringUtils.getTextCenter(link, "sign=", "#");
                            String appId = "88886666";
                            boolean REALLY_STARTAPP = true;
                            String chatUserType = "1";
                            String clientVersion = "10.0.0-5";
                            boolean startFromExternal = false;
                            String crowdId = StringUtils.getTextCenter(link, "crowdNo=", "&");
                            String socialCardToUserId = decode_pl_json.getString("to_u_id");
                            boolean appClearTop = false;
                            boolean REALLY_DOSTARTAPP = true;
                            String ap_framework_sceneId = "20000167";

                            Log.e("TAG", "消息 " + msgArr);
                            if ("COLLET".equals(biz_type) && content != null && content.contains("向你支付")) {
                                XposedBridge.log("删除好友" + userid);
                                PayHelperUtils.sendmsg(context, "收款成功删除好友:" + userid);
                                Message message = new Message();
                                message.what = 1;
                                message.obj = userid;
                                handler.sendMessageDelayed(message, 10000);

                            }
                            long nowTimetemp;
                            nowTimetemp = new Date().getTime();

                            if (nowTimetemp > 30000) {
                                XposedBridge.log("删除好友" + userid);
                                PayHelperUtils.sendmsg(context, "五分钟后删除好友:" + userid);
                                Message message = new Message();
                                message.what = 1;
                                message.obj = userid;
                                handler.sendMessageDelayed(message, 300000);

                            }
                            //自动回复
                            if (biz_type.equals("CHAT")) {
                                //TODO
                                Log.e("TAG", "收到消息");
                                if (content.contains("a")) {
                                    String money = content.split("a")[0];
                                    String remark = content.split("a")[1];
                                    Log.e("TAG", "发起收款：" + money);
                                    sendBillMsg(userid, money, remark);
                                    Log.e("TAG", "发起收款：" + money);
                                }
                            }


                        }
                    });


            //Accessibility
            XposedHelpers.findAndHookMethod(snsCou, "a", Context.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return false;
                }
            });


            // hook获取loginid
            XposedHelpers.findAndHookMethod("com.alipay.mobile.quinox.LauncherActivity", classLoader, "onResume",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            PayHelperUtils.isFirst = true;
                            String loginid = PayHelperUtils.getAlipayLoginId(classLoader);
                            PayHelperUtils.sendLoginId(loginid, "alipay", context);

                        }
                    });
        } catch (Error | Exception e) {
            PayHelperUtils.sendmsg(context, e.getMessage());
        }
    }

    public static String sendBillMsg(String userid, String money, String remark) {
        Class appclazz = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", mClassLoader);
        Object mapp2 = XposedHelpers.callStaticMethod(appclazz, "getInstance");
        Object bundleContext = XposedHelpers.callMethod(mapp2, "getBundleContext");
        ClassLoader classload = (ClassLoader) XposedHelpers.callMethod(bundleContext, "findClassLoaderByBundleName", "android-phone-wallet-socialpayee");
        Object service = com.tools.payhelper.v134.Tools.getRpcService(com.tools.payhelper.v134.Tools.getAlipayApplication(mClassLoader));
        XposedBridge.log("service " + service);
        Object SingleCollectRpc = XposedHelpers.callMethod(service, "getRpcProxy", XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.SingleCollectRpc", classload));
//        XposedBridge.log("SingleCollectRpc "+SingleCollectRpc);
        Object contactAccount = com.tools.payhelper.v134.Tools.getContactAccount(classload, userid);
        String name = XposedHelpers.getObjectField(contactAccount, "name") + "";
        String userId = XposedHelpers.getObjectField(contactAccount, "userId") + "";
        String logonId = XposedHelpers.getObjectField(contactAccount, "account") + "";
        Object singleCreateReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.req.SingleCreateReq", classload));
        XposedBridge.log(" singleCreateReq " + JSON.toJSONString(singleCreateReq));
        Field[] fields = singleCreateReq.getClass().getDeclaredFields();
        for (Field field : fields) {
            XposedBridge.log(" " + field.getName() + " " + field.getType());

        }
        XposedHelpers.setObjectField(singleCreateReq, "userName", name);
        XposedHelpers.setObjectField(singleCreateReq, "userId", userId);
        XposedHelpers.setObjectField(singleCreateReq, "logonId", logonId);
        XposedHelpers.setObjectField(singleCreateReq, "desc", remark);
        XposedHelpers.setObjectField(singleCreateReq, "payAmount", money);
        XposedHelpers.setObjectField(singleCreateReq, "billName", "个人收款");
        XposedHelpers.setObjectField(singleCreateReq, "source", "chat");
        Object o = XposedHelpers.callMethod(SingleCollectRpc, "createBill", singleCreateReq);
        XposedBridge.log(" 结果 " + JSON.toJSONString(o));
        return JSON.toJSONString(o);
    }


    private void securityCheckHook(ClassLoader classLoader) {
        try {
            Class<?> securityCheckClazz = XposedHelpers.findClass("com.alipay.mobile.base.security.CI", classLoader);
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", String.class, String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Object object = param.getResult();
                    XposedHelpers.setBooleanField(object, "a", false);
                    param.setResult(object);
                    super.afterHookedMethod(param);
                }
            });

            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", Class.class, String.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", ClassLoader.class, String.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return (byte) 1;
                }
            });
            XposedHelpers.findAndHookMethod(securityCheckClazz, "a", new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return false;
                }
            });

        } catch (Error | Exception e) {
            e.printStackTrace();
        }
    }

    public void startActivity(Context context, String packageName, String className) {

        Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.bill.list.ui.BillListActivity_", context.getClassLoader()));
        intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent2);
    }


    boolean isGetBanlance = false;
//    static Button quRenButton;


    boolean isSetMoney = false;
    float dmoney = 0;

    static String type = "";
    public static String BACK_HOME_ACTION_USERID = "com.tools.payhelper.backhomeuserid";

    public void hookActivityCreateFinish(final Context context, final ClassLoader classLoader) {
        try {

            XposedHelpers.findAndHookMethod("com.ali.user.mobile.login.ui.AliUserLoginActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    System.out.println("支付设置跳转回去1");
                    Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "mToken");
                    String money = (String) moneyField.get(param.thisObject);
                    XposedBridge.log("Hook支付宝开始.0........" + money);

                }
            });
            XposedHelpers.findAndHookMethod("com.alipay.mobile.verifyidentity.module.dynamic.ui.plugin.PasswordInputUnifiedPlugin", classLoader, "showKeyboard", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    System.out.println("支付设置跳转回去1");
                    XposedBridge.log("Hook支付宝开始.111........");

                }
            });
            XposedHelpers.findAndHookMethod("com.alipay.mobile.verifyidentity.module.dynamic.ui.plugin.PasswordInputUnifiedPlugin", classLoader, "a", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    System.out.println("支付设置跳转回去1");
                    String temp = param.args[0] + param.thisObject.getClass().getSimpleName() + "";
                    XposedBridge.log("Hook支付宝开始222........." + param.args.length + " " + temp);

                }
            });
            XposedHelpers.findAndHookMethod("com.alipay.android.app.safepaybase.widget.SafeInputWidget", classLoader, "d", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    System.out.println("支付设置跳转回去1");
                    String temp = param.args[0] + param.thisObject.getClass().getSimpleName() + "";
                    XposedBridge.log("Hook支付宝开始.333........" + param.args.length + " " + temp);

                }
            });
            XposedHelpers.findAndHookMethod("com.alipay.android.app.safepaybase.SafeInputContext", classLoader, "getEditContent", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    System.out.println("支付设置跳转回去1");

                    String temp = param.args[0] + param.thisObject.getClass().getSimpleName() + "";
                    XposedBridge.log("Hook支付宝开始.10........" + temp);
                }
            });
            //保活
            XposedHelpers.findAndHookMethod("com.alipay.android.phone.home.setting.MySettingActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    System.out.println("支付设置跳转回去1");
                    XposedBridge.log("Hook支付宝开始.112........");
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.setAction(BACK_HOME_ACTION_START);
                    context.sendBroadcast(broadCastIntent);
                    XposedHelpers.callMethod(param.thisObject, "finish", new Object[0]);
                }
            });

            //查询自己userid
            XposedHelpers.findAndHookMethod("com.alipay.mobile.payee.ui.PayeeQRActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    XposedBridge.log("Hook支付宝开始test11.........");
                    Field moneyField = XposedHelpers.findField(param.thisObject.getClass(), "f");
                    String userid = (String) moneyField.get(param.thisObject);
                    System.out.println("测试测试1== " + userid);

                    if (userid == null) {
                        userid = "";
                    }
                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("userid", userid);
                    broadCastIntent.setAction(BACK_HOME_ACTION_USERID);
                    context.sendBroadcast(broadCastIntent);
                }
            });

//提现界面，点击提现，全部，或者金额提现，
            XposedHelpers.findAndHookMethod("com.alipay.mobile.withdraw.ui.WithdrawActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(final MethodHookParam param) throws Throwable {
                    System.out.println(">>>>>>测试支付宝支付：开始");
                    Log.d("开始hook22=", "2、获得数据" + param.args[0] + "" + param.thisObject.getClass().getSimpleName() + "  " + param.args + "  结束");


                    param1 = param;

//                    pw = intent.getStringExtra("pw");
                    isGetBanlance = false;
                    XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, TextView.BufferType.class, boolean.class, int.class, new XC_MethodHook() {

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            String temp = param.args[0] + param.thisObject.getClass().getSimpleName() + "";
                            Log.d("开始hook", "2、获得数据" + param.args[0] + "" + param.thisObject.getClass().getSimpleName() + "  结束");


                            if (temp.contains("可用余额") && temp.contains("元APTextView") && isGetBanlance == false) {
                                //取出字符串中的钱
                                isGetBanlance = true;
                                isSetMoney = true;
                                dmoney = SocketClient.getDoubleValue(temp);
                                System.out.println("获取到支付宝余额=" + type);

                                if (type == null) {
                                    //啥也不干
                                } else if (type.equals("balance")) {
                                    //取出字符串中的钱。/并返回客户端界面
                                    float d = SocketClient.getDoubleValue(temp);
                                    System.out.println("获取到支付宝余额 " + type);
                                    Intent broadCastIntent = new Intent();
                                    broadCastIntent.putExtra("balance", d + "");
                                    broadCastIntent.putExtra("type", "alipay");
                                    broadCastIntent.setAction(BALANCERECEIVED_ACTION);
                                    context.sendBroadcast(broadCastIntent);
//                                    XposedHelpers.callMethod(param1.thisObject, "finish", new Object[0]);
                                } else if (type.equals("withdraw")) {

                                }
//
                            } else if (temp.contains("提现申请已提交，等待银行处理APTextView")) {
                                //提现结束了，返回app主页，数据库清除,执行下一个任务
                            }
                        }

                    });


                }
            });


            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(final MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);

                    XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, TextView.BufferType.class, boolean.class, int.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            String temp = param.args[0] + param.thisObject.getClass().getSimpleName() + "";
                            Log.d("开始hook", "2、获得数据" + param.args[0] + "" + param.thisObject.getClass().getSimpleName() + "  结束");
                        }

//                @Override
//                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//                    String text = (String) param.args[0];
////                    if("0.00".equals(text)){
////                        param.args[0] = "10000000.00";
////                    }if("可用余额 0.00元".equals(text)){
////                        param.args[0] = "可用余额 10000000.00元";
////                    }
//                    Log.d("开始hook", "3、获得数据！" + param.args[0]+"  结束");
//                }
                    });

                    PayHelperUtils.sendmsg(context, ":load activity:" + param.thisObject.getClass().getPackage() + "=======" + param.thisObject.getClass().getSimpleName());
                    Log.e(">>>>>>>>>>test0:==", ":load activity:" + param.thisObject.getClass().getPackage() + "=======" + param.thisObject.getClass().getSimpleName());


                }
            });

        } catch (Error | Exception e) {
            Log.e("test临时", "hookTFAccount error:" + e.getMessage());
        }


    }

    static XC_MethodHook.MethodHookParam param1 = null;
    static XC_MethodHook.MethodHookParam param2 = null;


    static void replaceDetailPage(final Context context) {
        //hook rpc  QuerySingleBillDetail替换成QuerySingleBillDetailForH5
        ClassLoader classLoader = context.getClassLoader();
        XposedHelpers.findAndHookMethod("com.alipay.mobile.common.rpc.util.RpcInvokerUtil", classLoader, "getOperationTypeValue", Method.class, Object[].class, new

                XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if (param.getResult() == null) {
                            return;
                        }
                        try {
                            String operationTypeValue = (String) param.getResult();
                            if ("alipay.mobile.bill.QuerySingleBillDetail".equals(operationTypeValue)) {
                                param.setResult("alipay.mobile.bill.QuerySingleBillDetailForH5");
                            }
                        } catch (Exception ex) {
                        }
                    }
                });
    }


    static void getBillList(final Context context, String money) {
        ClassLoader loader = context.getClassLoader();
        Class ServiceUtil = XposedHelpers.findClass("com.alipay.mobile.beehive.util.ServiceUtil", loader);
        Class RpcService = XposedHelpers.findClass("com.alipay.mobile.framework.service.common.RpcService", loader);
        Class BillListPBRPCService = XposedHelpers.findClass("com.alipay.mobilebill.biz.rpc.bill.v9.pb.BillListPBRPCService", loader);
        final Object RpcProxy = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(ServiceUtil, "getServiceByInterface", RpcService), "getRpcProxy", BillListPBRPCService);
        final Object QueryListReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilebill.common.service.model.pb.QueryListReq", loader));
        XposedHelpers.setObjectField(QueryListReq, "category", "ALL");
        XposedHelpers.setObjectField(QueryListReq, "pageType", "WaitPayConsumeQuery");
        XposedHelpers.setObjectField(QueryListReq, "paging", XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilebill.common.service.model.pb.PagingCondition", loader)));
        XposedHelpers.setObjectField(QueryListReq, "needMonthSeparator", Boolean.FALSE);
        XposedHelpers.setObjectField(QueryListReq, "scene", "BILL_LIST");
        long currentTimeMillis = System.currentTimeMillis();
        XposedHelpers.setObjectField(QueryListReq, "startTime", currentTimeMillis - 60 * 3 * 1000);
        XposedHelpers.setObjectField(QueryListReq, "endTime", currentTimeMillis);
        XposedHelpers.setObjectField(QueryListReq, "dateType", "day");
        new Thread() {
            @SuppressLint("CheckResult")
            public void run() {
                List billListItems = (List) XposedHelpers.getObjectField(XposedHelpers.callMethod(RpcProxy, "query", QueryListReq), "billListItems");
                Log.d("#####","抓取到:" + billListItems.size() + "条账单");

                String data = JSON.toJSON(billListItems).toString();
                Log.d("#####",data + "-------");

                com.alibaba.fastjson.JSONArray array = JSON.parseArray(data);
                for (int i = 0; i < array.size(); i++) {
                    com.alibaba.fastjson.JSONObject object = (com.alibaba.fastjson.JSONObject) array.get(i);
                    String orderNo = object.getString("bizInNo");
                    String consumeFee = object.getString("consumeFee").replace("+", "")
                            .replace(",", "");

                    Log.d("#####","订单号:" + orderNo + "金额" + consumeFee);

                    //获取当前订单,去查看详情
                    Log.d("#####","当前订单号:" + orderNo);
                    //替换
                    replaceDetailPage(context);
                    //固码详情
                    billGDetail(context, orderNo, "TRADE", consumeFee,"");
                }
            }
        }.start();
    }


    static void billGDetail(final Context context, final String bizInNo, String bizType, final String money, final String mark) {
        //
        AlipayHookHelper.getBillDetail(bizInNo, bizType, new
                AlipayRpcRunnable() {
                    @Override
                    public void rpcResult(Object obj) {
                        try {
                            Log.i("#####testBroadReceived", "rpcResult:" + JSON.toJSONString(obj));
                            Class<?> resClass = obj.getClass();
                            Field field = resClass.getDeclaredField("extension");
                            Map<String, String> extension = (Map<String, String>) field.get(obj);
                            String mdata = extension.get("mdata");
                            Log.i("####testBroadReceived", "mdata:" + mdata);
                            if (mdata == null) {
                                return;
                            }
                            JSONObject jsonObject = new JSONObject(mdata);
                            final String conbiz_opp_uid = jsonObject.getString("conbiz_opp_uid");
                            Log.i("####testBroadReceived:", "conbiz_opp_uid:" + conbiz_opp_uid);


                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", bizInNo);
                            broadCastIntent.putExtra("bill_money", money.replace("￥", ""));
                            broadCastIntent.putExtra("bill_mark", mark);
                            broadCastIntent.putExtra("bill_type", "alipay");
                            broadCastIntent.putExtra("bill_pay_user_id", conbiz_opp_uid);

                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);

                        } catch (Exception ex) {
                            Log.i("####testBroadReceived:", "getBillDetail Err:" + ex);
                            ex.printStackTrace();
                        }
                    }
                });
    }

    static void billDetail(final Context context, final String bizInNo, String bizType, final String money, final String mark) {
        //
        AlipayHookHelper.getBillDetail(bizInNo, bizType, new
                AlipayRpcRunnable() {
                    @Override
                    public void rpcResult(Object obj) {
                        try {
                            Log.i("#####testBroadReceived", "rpcResult:" + JSON.toJSONString(obj));
                            Class<?> resClass = obj.getClass();
                            Field field = resClass.getDeclaredField("extension");
                            Map<String, String> extension = (Map<String, String>) field.get(obj);
                            String mdata = extension.get("mdata");
                            Log.i("####testBroadReceived", "mdata:" + mdata);
                            if (mdata == null) {
                                return;
                            }
                            JSONObject jsonObject = new JSONObject(mdata);
                            final String conbiz_opp_uid = jsonObject.getString("conbiz_opp_uid");
                            Log.i("####testBroadReceived:", "conbiz_opp_uid:" + conbiz_opp_uid);


                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("bill_no", bizInNo);
                            broadCastIntent.putExtra("bill_money", money.replace("￥", ""));
                            broadCastIntent.putExtra("bill_mark", mark);
                            broadCastIntent.putExtra("bill_type", "alipay");
                            broadCastIntent.putExtra("bill_pay_user_id", conbiz_opp_uid);

                            broadCastIntent.setAction(BILLRECEIVED_ACTION);
                            context.sendBroadcast(broadCastIntent);

                        } catch (Exception ex) {
                            Log.i("####testBroadReceived:", "getBillDetail Err:" + ex);
                            ex.printStackTrace();
                        }
                    }
                });
    }


}